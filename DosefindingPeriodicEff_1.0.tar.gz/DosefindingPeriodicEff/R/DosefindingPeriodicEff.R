MCMC_Dose_Finding_Periodic_Eff <- function(hyper, cur_data, J, K, L, M, zeta_bar, p_star, dose, accp_chk, follow_up, utility, ini_sam, n_sam, n_burn)
{
    set.seed(879789)

    ### hyperparameters
    Omega0_mat <- array(hyper$Omega0, dim=c((J+1)*(J+1),1))[,1]
    
    ### data
    Y_mat <- array(cur_data$Y_obs, dim=c(cur_data$N_t*J,1))[,1]
    
    Delta_mat <- cur_data$delta
    Delta_mat[,3] <- cur_data$ind_PD
    Delta_mat <- array(Delta_mat, dim=c(cur_data$N_t*J,1))[,1]
    
    Z_mat <- array(cur_data$Z_obs, dim=c(cur_data$N_t*L,1))[,1]
    
    ### compute ut
    Ut_mat <- array(utility, dim=c(11*3, 1))[,1]
    
    #### cur-sam
    if(nrow(ini_sam$gam) < cur_data$N_t)
    {
        ini_sam$gam <- rbind(ini_sam$gam, rep(0, (cur_data$N_t - nrow(ini_sam$gam))))
    }
    
    gam_mat <- array(ini_sam$gam, dim=c(cur_data$N_t*(J + 1),1))[,1]
    lam_mat <- array(ini_sam$lam, dim=c(hyper$max_QQ*J,1))[,1]
    SS_mat <- array(ini_sam$SS, dim=c((hyper$max_QQ+1)*J,1))[,1]
    Inv_Omega <- array(ini_sam$Inv_Omega, dim=c((J+1)*(J+1),1))[,1]
    
    #### do MCMC and save samples
    output <- .C("fn_Discrete_MCMC_U", dose=as.double(cur_data$dose), YY=as.double(Y_mat), Z_obs=as.integer(Z_mat), Delta=as.integer(Delta_mat), ##
    Q_max = as.integer(hyper$max_QQ), QQ = as.integer(hyper$QQ), SS=as.double(SS_mat), ##
    lam = as.double(lam_mat), sig2=as.double(hyper$sig2), lam0=as.double(hyper$lam0), sig2_0=as.double(hyper$sig2_0),
    Be = as.double(ini_sam$Be), Be_bar = as.double(hyper$be_bar), tau2 = as.double(hyper$tau2), ##
    xi = as.double(ini_sam$xi), xi_bar = as.double(hyper$xi_bar), tau2_xi = as.double(hyper$tau2_xi), ##
    phi = as.double(ini_sam$phi), phi_bar = as.double(hyper$phi_bar), tau2_phi = as.double(hyper$tau2_phi), ##
    Alpha = as.double(ini_sam$Alpha), Alpha_bar = as.double(hyper$Alpha_bar), v2_alpha = as.double(hyper$v2_alpha), ##
    sig2_pi = as.double(hyper$sig2_pi), u_cutoff = as.double(hyper$u_cutoff), ##
    gam = as.double(gam_mat), nu = as.integer(hyper$nu), Omega0 = as.double(Omega0_mat), Inv_Omega = as.double(Inv_Omega), ##
    JJ=as.integer(J), JJ_1=as.integer(K), NNt=as.integer(cur_data$N_t), N_burn=as.integer(n_burn), N_iter=as.integer(n_sam), ##
    std_dose=as.double(dose), MM=as.integer(M), Cens=as.double(follow_up), pi_bar_S=as.double(zeta_bar), Ut_tab=as.double(Ut_mat), Tab_Safety=as.integer(rep(0, M)), Tab_Exp_Ut=as.double(rep(0, M)))
    
    #cat("\n\n")
    #print(output$Tab_Exp_Ut)
    
    ### update the current sample
    ini_sam$lam <- array(output$lam, dim=c(hyper$max_QQ, J))
    ini_sam$SS <- array(output$SS, dim=c(hyper$max_QQ+1, J))
    
    ini_sam$Be <- output$Be
    
    ini_sam$xi <- output$xi
    ini_sam$phi <- output$phi
    ini_sam$Alpha <- output$Alpha
    
    ini_sam$Inv_Omega <- array(output$Inv_Omega, dim=c(J+1, J+1))
    ini_sam$Omega <- solve(ini_sam$Inv_Omega)
    ini_sam$gam <- array(output$gam, dim=c(cur_data$N_t, J+1))
    
    ### save safety and expect Ut
    Prob_Safety <- output$Tab_Safety/n_sam
    ## print(Tab_Safety/n_sam)
    Tab_Safety <- 1 - (Prob_Safety > p_star)*1
    
    if(accp_chk == 0)
    {
        Tab_Safety <- rep(1, M) ## all doses are acceptable
    }
    
    Tab_Exp_Ut <- output$Tab_Exp_Ut
    
    return(list(Tab_Safety=Tab_Safety, Exp_Ut=Tab_Exp_Ut, cur_sam=ini_sam, Prob_Safety=Prob_Safety))
}

