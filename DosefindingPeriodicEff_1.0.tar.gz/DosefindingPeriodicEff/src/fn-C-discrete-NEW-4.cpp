#include <cstdio>
#include <cstddef>
#include <cstdlib>
#include <cmath>
#include <cassert>
#include <algorithm>
#include <iterator>

#include <R.h>
#include <Rmath.h>
#include <R_ext/Lapack.h>

//R CMD SHLIB -lRlapack fn-C-discrete-NEW-4.cpp
extern "C"
{
    double fn_lgamma(double x)
    {
        double x0,x2,xp,gl,gl0;
        int n,k;
        static double a[] = {
            8.333333333333333e-02,
            -2.777777777777778e-03,
            7.936507936507937e-04,
            -5.952380952380952e-04,
            8.417508417508418e-04,
            -1.917526917526918e-03,
            6.410256410256410e-03,
            -2.955065359477124e-02,
            1.796443723688307e-01,
            -1.39243221690590};
        
        x0 = x;
        if (x <= 0.0) return 1e308;
        else if ((x == 1.0) || (x == 2.0)) return 0.0;
        else if (x <= 7.0) {
            n = (int)(7-x);
            x0 = x+n;
        }
        
        x2 = 1.0/(x0*x0);
        xp = 2.0*M_PI;
        gl0 = a[9];
        
        for (k=8;k>=0;k--) {
            gl0 = gl0*x2 + a[k];
        }
        
        gl = gl0/x0+0.5*log(xp)+(x0-0.5)*log(x0)-x0;
        if (x <= 7.0) {
            for (k=1;k<=n;k++) {
                gl -= log(x0-1.0);
                x0 -= 1.0;
            }
        }
        return gl;
    }
    
    
    //MATRIX COMPUTATION A%*%x
    void Ax(double *A, double *x, double *z, int p)
    {
        int _i, _j;
        
        for(_i=0;_i<p;_i++)
            for(z[_i]=0,_j=0; _j<p; _j++)
                z[_i] += A[_j + _i*p]*x[_j];
    }
    
    
    
    // generate samples from N(0, Sig=) where sq_Sigma = \sqrt(Sigma)
    void mvn_rv(int p, double *sq_Sigma, double *x)
    {
        int i;
        double *eps;
        
        eps = new double[p];
        
        for(i=0; i < p; i++){
            //# random walk
            GetRNGstate();
            eps[i] = rnorm(0, 1.0); //eps ~ N(0,1)
            PutRNGstate();
        }
        
        Ax(sq_Sigma, eps, x, p);  //x=V%*%eps ~ N(0, Sig)
        
        
        //Delete the memory
        delete[] eps; eps=  NULL;
        
        return;
    }
    
    
    
    void EigenDecomp(int N, double* A, double* eval, double* evec)
    {
        int          i;
        int          LWORK = 3*N-1;
        int          INFO = 0;
        char         UPLO = 'U';
        char         JOBZ = 'V';
        
        //double* W = new double[N];
        double* WORK = new double[3*N-1];
        double* Acopy = new double[N*N];
        
        for(i=0; i<(N*N);  i++) Acopy[i] = A[i];
        
        dsyev_(&JOBZ, &UPLO, &N, Acopy, &N, eval, WORK, &LWORK, &INFO);
        
        for(i=0; i<(N*N); i++) evec[i] = Acopy[i];
        
        delete[] WORK; WORK = NULL;
        delete[] Acopy; Acopy = NULL;
        
        return;
    }
    
    // Find the square root inverse of p*p matrix Sig and save it in L
    void fn_sq_inverse_mat(int p, double* Sig, double *L)
    {
        int i, j, j2;
        double *Tmp;
        Tmp = new double[p*p];
        
        //Sig=Q%*%diag(eigenvalues)%*%solve(Q) where Q's i-th column is the eigenvector of Sig
        //Sig=V%*%t(V) and L=solve(V)=diag(1/sqrt(eigenvalues))%*%t(Q)
        double *eval; eval = new double[p];
        double *evec; evec = new double[p*p];
        
        // find eigenvalues and eigenvectors of Sigma
        EigenDecomp(p, Sig, eval, evec);
        
        //COMPUTE V (L=solve(Sigma))
        for (i=0; i < p; i++) {
            for (j=0; j < p; j++) {
                Tmp[j*p + i]=evec[j*p + i]/sqrt(eval[j]);
            }
        }
        
        //COMPUTE V (L=solve(Sigma))
        for (i=0; i < p; i++) {
            for (j=0; j < p; j++) {
                // L[i,j]
                L[j*p+i] = 0.0;
                
                for (j2=0; j2 < p; j2++) {
                    L[j*p+i] = L[j*p+i] + Tmp[j2*p + i]*evec[j2*p + j];
                }
            } //for (j=0; j < p; j++) {
        }//for (i=0; i < p; i++) {
        
        delete[] eval; eval= NULL;
        delete[] evec; evec= NULL;
        delete[] Tmp; Tmp= NULL;
        
        return;
    }
    
    // Find the inverse of p*p matrix Sig and save it in L
    void fn_inverse_mat(int p, double* Sig, double *L)
    {
        int i, j, j2;
        double *Tmp;
        Tmp = new double[p*p];
        
        //Sig=Q%*%diag(eigenvalues)%*%solve(Q) where Q's i-th column is the eigenvector of Sig
        //Sig=V%*%t(V) and L=solve(V)=diag(1/sqrt(eigenvalues))%*%t(Q)
        double *eval; eval = new double[p];
        double *evec; evec = new double[p*p];
        
        // find eigenvalues and eigenvectors of Sigma
        EigenDecomp(p, Sig, eval, evec);
        
        //COMPUTE V (L=solve(Sigma))
        for (i=0; i < p; i++) {
            for (j=0; j < p; j++) {
                Tmp[j*p + i]=evec[j*p + i]/eval[j];
            }
        }
        
        //COMPUTE V (L=solve(Sigma))
        for (i=0; i < p; i++) {
            for (j=0; j < p; j++) {
                // L[i,j]
                L[j*p+i] = 0.0;
                
                for (j2=0; j2 < p; j2++) {
                    L[j*p+i] = L[j*p+i] + Tmp[j2*p + i]*evec[j2*p + j];
                }
            } //for (j=0; j < p; j++) {
        }//for (i=0; i < p; i++) {
        
        delete[] eval; eval= NULL;
        delete[] evec; evec= NULL;
        delete[] Tmp; Tmp= NULL;
    }
    
    // W_sam ~ Wishart(df, Omega^{-1}=Sigma)  ( W_sam^{-1} ~ Inverse_Wishart(df, Omega))
    void fn_Wishart_sample(int df, int p, double *Omega, double *W_sam)
    {
        int i1, j1, j2;
        double *sq_Sigma, *x, tmp;
        
        //sq_Sigma = new double[p*p]; // p*p-matrix but in a vector form
        x = new double[p]; // p-dim vector
        sq_Sigma = new double[p*p];
        
        //Omega_p=Q%*%diag(eigenvalues)%*%solve(Q) where Q's i-th column is the eigenvector of Sig
        //sq_Sig=(Omega_p)^{-1/2} so sq_Sig = solve(V)=diag(1/sqrt(eigenvalues))%*%t(Q)
        fn_sq_inverse_mat(p, Omega, sq_Sigma);
        
        // initialize
        for (i1 =0 ; i1 < (p*p); i1++) {
            W_sam[i1] = 0.0;
        }
        
        // sample W_sam ~ Wishart(df, Omega^{-1}=Sigma)
        for (i1 = 0; i1 < df; i1++) {
            
            // sample x ~ N(0, Sigma)
            mvn_rv(p, sq_Sigma, x);
            
            for (j1=0; j1 < p; j1++) {
                
                // diagonal
                tmp = x[j1]*x[j1];
                W_sam[j1*p + j1] = W_sam[j1*p + j1] + tmp;
                
                // off-diagonal
                for (j2=(j1+1); j2 < p; j2++) {
                    tmp = x[j1]*x[j2];
                    
                    W_sam[j1*p + j2] = W_sam[j1*p + j2] + tmp;
                    W_sam[j2*p + j1] = W_sam[j1*p + j2];
                }
            }//for (j1=0; j1 < JJ; j1++) {
        } //for (i1 = 0; i1 < df; i1++) {
        
        delete[] sq_Sigma; sq_Sigma= NULL;
        delete[] x; x= NULL;
    }
    
    
    /*
     ###  update Omega (variance for random effects)
     ##
     fn_update_Inv_Omega(gam, *a_omega, Omega_0, *NNt, (*JJ + 1), Inv_Omega);
     
     # JJ=3:  the number of outcomes  so (J+1)=4 is passed
     # n_t: n(t) the number of patients by time t
     # Rand_u: Patients random effects --  n(t)*(J+1) matrix
     
     ## gam_i \sim N_4(0, \Omega) where gam_i=(gam_Di, gam_Ti, gam_PD1i, gam_PD2i)
     ## \Omega: (J+1)*(J+1) covariance matrix
     */
    void fn_update_Inv_Omega(double *Rand_u, int nu, double *Omega_0, int n_t, int JJ, double *Inv_Omega)
    {
        int i, j1, j2;
        double *Omega0_p, tmp;
        
        //Allocate the memory
        Omega0_p = new double[JJ*JJ]; // JJ*JJ-matrix but in a vector form
        
        // Let Sigma=Omega_0
        for (j1 = 0; j1 < (JJ*JJ); j1++) {
            Omega0_p[j1] = Omega_0[j1];
        }
        
        // compute \sum_t u_i*t(u_i)
        for (i=0; i < n_t; i++)
        {
            for (j1=0; j1 < JJ; j1++) {
                
                // diagonal
                tmp = Rand_u[j1*n_t + i]*Rand_u[j1*n_t + i];
                Omega0_p[j1*JJ + j1] = Omega0_p[j1*JJ + j1] + tmp;
                
                // off-diagonal
                for (j2=(j1+1); j2 < JJ; j2++) {
                    tmp = Rand_u[j1*n_t + i]*Rand_u[j2*n_t + i];
                    
                    Omega0_p[j1*JJ + j2] = Omega0_p[j1*JJ + j2] + tmp;
                    Omega0_p[j2*JJ + j1] = Omega0_p[j1*JJ + j2];
                }
            }//for (j1=0; j1 < JJ; j1++) {
        }//for (i=0; i < n_t; i++)
        
        // Now Omegam_p = \sum_i u_i t(u_i) + \Omega_0
        
        // Sample Inv_Omega ~ Wishart(n_t+nu, Omega0_p^{-1}) (==> Omega ~ Inverse-Wishart(n_t+nu, Omega0_p)
        fn_Wishart_sample((n_t+nu), JJ, Omega0_p, Inv_Omega);
        
        // Free the memory
        delete[] Omega0_p; Omega0_p = NULL;
    }
    
    
    //t(vector)%*%Matrix%*%vector
    double xAx(double *x, double *A, int p)
    {
        int _i, _j;
        double y = 0.0;
        double *z; z = new double[p];
        
        for(_i=0; _i < p ;_i++){ //row i
            // A%*%x first
            for(z[_i]=0, _j=0; _j < p; _j++)
            {
                //printf("\n A=%f, x=%f", A[_i + _j*p], x[_j]);
                z[_i]+=A[_i + _j*p]*x[_j];
            }
        }//for(_i=0; _i < p ;_i++){ //row i
        
        // now multiply by t(x)
        for (_i=0; _i < p; _i++) {
            y = y + z[_i]*x[_i];
        }
        
        delete z; z= NULL;
        
        return(y);
    }
    
    //fn_compute_log_PPi(z_1, u, u_cutoff, sig2_pi, JJ_1)
    // #####  A_cur = A_cur + fn_compute_log_PPi(z_1, u_cur, u_cutoff, sig2_pi);
    double fn_compute_log_PPi(int z, double m, double *u_cutoff, double v, int JJ_1)
    {
        double tmp0, tmp1, log_pi=0.0;
        
        //printf("\n\n cut=%f, %f, %f", u_cutoff[0], u_cutoff[1], u_cutoff[2]);
        
        // Z=0: ppi0 = P(X < cutoff[0]) where X ~N(m, sig2_pi)
        //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        if (z == 0) {
            log_pi = pnorm(u_cutoff[z], m, sqrt(v), 1, 0);
            //printf("\n z=%d, cut=%f, m=%f, v=%f, log_pi=%f", z, u_cutoff[z], m, v, log_pi);
            
            if (log_pi < 0.001) {// if the prob is too small, then let it be a very small number
                log_pi = -10000000.0;
            }else{
                log_pi = log(log_pi);
            }
        }//if (z == 0) {
        
        if ((z > 0)&&(z < (JJ_1 - 1))) { // z= 1, 2
            tmp0 = pnorm(u_cutoff[z-1], m, sqrt(v), 1, 0);  //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
            tmp1 = pnorm(u_cutoff[z], m, sqrt(v), 1, 0);    //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
            log_pi = (tmp1 - tmp0);

            //printf("\n z=%d, cut-b=%f,cut-a=%f, m=%f, v=%f, log_pi=%f", z, u_cutoff[z-1], u_cutoff[z], m, v, log_pi);

            if (log_pi < 0.001) {  // if the prob is too small, then let it be a very small number
                log_pi = -10000000.0;
            }else{
                log_pi = log(log_pi);
            }//if (log_pi < 0.001) {
        } // if ((z > 0)&(z < (JJ_1 - 1))) {
        
        if (z == (JJ_1 - 1)) { //z=3
            log_pi = pnorm(u_cutoff[z-1], m, sqrt(v), 0, 0);
            
            //printf("\n z=%d, cut=%f, m=%f, v=%f, log_pi=%f", z, u_cutoff[z-1], m, v, log_pi);
            
            if (log_pi < 0.001) {// if the prob is too small, then let it be a very small number
                log_pi = -10000000.0;
            }else{
                log_pi = log(log_pi);
            }
        }// if (z == (JJ_1 - 1)) { //z=3
        
        return log_pi;
    }

    
    /*
     ###  update u (random effects)  -- all elements once
     ##
     # JJ==3:  the number of outcomes
     # n_t: n(t) the number of patients by time t
     # gam: Patients random effects --  n(t)*(J + 1) matrix gam=(gam_D, gam_T, gam_PD, gam_PDz)
     
     ## u_i \sim N_4(0, \Omega)
     ## \Omega: (J+1)*(J+1) covariance matrix
     ## eta -- eta but without gamma
     
     ### Delta: censoring indicator for patients and for outcomes -- n(t)*J matrix
     ## delta for PD: 1 if PD is observed from symptoms or signs (not from imaging)
     */
    void fn_update_u_1(int NNt, int JJ, int JJ_1, double *u_cutoff, int *Delta, int *Z_obs, double *eta, double *eta_Z, double sig2_pi, double *KK_sum, double *gam_cur, double *Inv_Omega)
    {
        int i_n, j, s_ind, z_1, z_2;
        double *u_cur, *u_pro, A_cur, A_pro, u;
        double sd_MH = 0.2;
        
        //Allocate the memory
        u_cur = new double[JJ + 1]; // J-dim vector
        u_pro = new double[JJ + 1]; // J-dim vector
        
        for (i_n = 0; i_n < NNt; i_n ++)
        {
            //## copy the current & propose
            for (j=0; j < (JJ + 1); j++) {
                u_cur[j] = gam_cur[NNt*j + i_n];
                
                //# random walk
                GetRNGstate();
                u_pro[j] = u_cur[j] + rnorm(0.0, sd_MH);
                PutRNGstate();
            } // for (j=0; j < JJ; j++) {
            
            //## Prior
            A_cur = - xAx(u_cur, Inv_Omega, JJ + 1)/2.0; //  ## priors
            A_pro = - xAx(u_pro, Inv_Omega, JJ + 1)/2.0; //  ## priors
            
            // go over continuous outcomes
            for (j=0; j < JJ; j++) {
                s_ind = j*NNt;
                A_cur = A_cur + 1.0*Delta[s_ind + i_n]*u_cur[j] - exp(eta[s_ind + i_n] + u_cur[j])*KK_sum[s_ind + i_n];
                A_pro = A_pro + 1.0*Delta[s_ind + i_n]*u_pro[j] - exp(eta[s_ind + i_n] + u_pro[j])*KK_sum[s_ind + i_n];
            } //for (j=0; j < JJ; j++) {
            
            // PD - Z
            j = JJ;
            s_ind = NNt*j;
            
            z_1 = Z_obs[i_n];
            if(z_1 >= 0)  //### imaging at t*_1 is done
            {
                A_cur = A_cur + fn_compute_log_PPi(z_1, eta_Z[i_n] + u_cur[j], u_cutoff, sig2_pi, JJ_1);
                A_pro = A_pro + fn_compute_log_PPi(z_1, eta_Z[i_n] + u_pro[j], u_cutoff, sig2_pi, JJ_1);
                
                //##### if imaging at t*_2 is done
                z_2 = Z_obs[NNt + i_n];
                if(z_2 >= 0) //### imaging at t*_2 is done (meaning at least SD at t*_1 & still survived & no PD upto t*_2)
                {
                    A_cur = A_cur + fn_compute_log_PPi(z_2, eta_Z[NNt + i_n] + u_cur[j], u_cutoff, sig2_pi, JJ_1);
                    A_pro = A_pro + fn_compute_log_PPi(z_2, eta_Z[NNt + i_n] + u_pro[j], u_cutoff, sig2_pi, JJ_1);
                } //## if(z_2 >= 0)
            } //# if(z_1 >= 0)
            
            //Let's do M-H
            GetRNGstate();
            u = runif(0.0, 1.0);
            PutRNGstate();
            
            //### Accept?
            if(log(u) < (A_pro - A_cur))
            {
                //## copy
                for (j=0; j < (JJ + 1); j++) {
                    gam_cur[NNt*j + i_n] = u_pro[j];
                } // for (j=0; j < JJ; j++) {
            }//if(log(u) < (A_pro - A_cur))
        } //for (i=0; i < n_t; i++)
        
        
        // Free the memory
        delete[] u_cur; u_cur = NULL;
        delete[] u_pro; u_pro = NULL;
    }
    
    
    
    
    /*
     ###  update u (random effects)
     ##
     # JJ==3:  the number of outcomes
     # n_t: n(t) the number of patients by time t
     # gam: Patients random effects --  n(t)*(J + 1) matrix gam=(gam_D, gam_T, gam_PD, gam_PDz)
     
     ## u_i \sim N_4(0, \Omega)
     ## \Omega: (J+1)*(J+1) covariance matrix
     
     ### Delta: censoring indicator for patients and for outcomes -- n(t)*J matrix
     */
    void fn_update_u_0(int NNt, int JJ, int JJ_1, double *u_cutoff, int *Delta, int *Z_obs, double *eta, double *eta_Z, double sig2_pi, double *KK_sum, double *gam_cur, double *Inv_Omega)
    {
        int i_n, j, s_ind, z_1, z_2;
        double *u_cur, *u_pro, A_cur, A_pro, u;
        double sd_MH = 0.5;
        
        //Allocate the memory
        u_cur = new double[JJ + 1]; // J-dim vector
        u_pro = new double[JJ + 1]; // J-dim vector
        
        for (i_n = 0; i_n < NNt; i_n ++)
        {
            //## copy
            for (j=0; j < (JJ + 1); j++) {
                u_cur[j] = gam_cur[NNt*j + i_n];
                u_pro[j] = u_cur[j];
            } // for (j=0; j < JJ; j++) {
            
            //printf("\n ");
            
            //## for D, T and continuous PD
            for (j=0; j < JJ; j++) {
                s_ind = j*NNt;
                
                //# random walk
                GetRNGstate();
                u_pro[j] = u_cur[j] + rnorm(0.0, sd_MH);
                PutRNGstate();
                
                //## Prior
                A_cur = - xAx(u_cur, Inv_Omega, JJ + 1)/2.0; //  ## priors
                A_pro = - xAx(u_pro, Inv_Omega, JJ + 1)/2.0; //  ## priors
                
                //## compute lambda_i with proposed u
                A_cur = A_cur + 1.0*Delta[s_ind + i_n]*u_cur[j] - exp(eta[s_ind + i_n] + u_cur[j])*KK_sum[s_ind + i_n];
                A_pro = A_pro + 1.0*Delta[s_ind + i_n]*u_pro[j] - exp(eta[s_ind + i_n] + u_pro[j])*KK_sum[s_ind + i_n];
                
                //Let's do M-H
                GetRNGstate();
                u = runif(0.0,1.0);
                PutRNGstate();
                
                //### Accept?
                if(log(u) < (A_pro - A_cur))
                {
                    u_cur[j] = u_pro[j];
                    gam_cur[s_ind + i_n] = u_cur[j];
                    
                }else{// if(log(u) < (A_pro - A_cur))
                    u_pro[j] = u_cur[j];
                }
                
                //printf("\n i_n=%d j=%d gam=%f", i_n, j,  gam_cur[s_ind + i_n]);
            } //for (j=0; j < JJ; j++) {
            
            // for discrete PD: PD - Z
            j = JJ;
            s_ind = NNt*j;
            
            //# random walk
            GetRNGstate();
            u_pro[j] = u_cur[j] + rnorm(0, sd_MH/2.0);
            PutRNGstate();
            
            //## Prior
            A_cur = - xAx(u_cur, Inv_Omega, JJ + 1)/2.0; //  ## priors
            A_pro = - xAx(u_pro, Inv_Omega, JJ + 1)/2.0; //  ## priors
            
            // if no imaging is done, no contribution from the likelihood (i.e., sampling from the prior)
            z_1 = Z_obs[i_n];
            
            if(z_1 >= 0)  //### imaging at t*_1 is done
            {
                A_cur = A_cur + fn_compute_log_PPi(z_1, eta_Z[i_n] + u_cur[j], u_cutoff, sig2_pi, JJ_1);
                A_pro = A_pro + fn_compute_log_PPi(z_1, eta_Z[i_n] + u_pro[j], u_cutoff, sig2_pi, JJ_1);
                
                //##### if imaging at t*_2 is done
                z_2 = Z_obs[NNt + i_n];
                if(z_2 >= 0) //### imaging at t*_2 is done (meaning at least SD at t*_1 & still survived & no PD upto t*_2)
                {
                    A_cur = A_cur + fn_compute_log_PPi(z_2, eta_Z[NNt + i_n] + u_cur[j], u_cutoff, sig2_pi, JJ_1);
                    A_pro = A_pro + fn_compute_log_PPi(z_2, eta_Z[NNt + i_n] + u_pro[j], u_cutoff, sig2_pi, JJ_1);
                } //## if(z_2 >= 0)
            } //# if(z_1 >= 0)
            
            //Let's do M-H
            GetRNGstate();
            u = runif(0.0,1.0);
            PutRNGstate();
            
            //### Accept?
            if(log(u) < (A_pro - A_cur))
            {
                gam_cur[s_ind + i_n] = u_pro[j];
            }// don't need to copy curret to pro
            
            //printf("\n i_n=%d j=%d, A_cur=%f, A_pro=%f, gam=%f", i_n, j,  A_cur, A_pro, gam_cur[s_ind + i_n]);
        } //for (i=0; i < n_t; i++)
        
        
        // Free the memory
        delete[] u_cur; u_cur = NULL;
        delete[] u_pro; u_pro = NULL;
    }
    
    // unpdate random effects -- gam_i: JJ+1 vector -- D, T, PD1, PD2 with JJ=3
    // alpha=(0, 0, alpha_2, alpha_3) with alpha_{k-1} < alpha_k
    // ind_all = 0 => update gam_ij one at a time, ind_all = 1 => update gam_i as a vector
    //
    void fn_update_gam(int NNt, int JJ, int JJ_1, double *u_cutoff, double *dose, double *gam_cur, double *Inv_Omega,
                       int *Delta, int *Z_obs, double *KK_sum,
                       double *Be, double phi, double *xi, double *Alpha, double sig2_pi, int ind_all) //PD
    {
        int i_n, s_ind, z_1, z_2;
        double dose_i;
        double *eta; eta = new double[NNt*JJ]; // (Death, Tox, PD conti)
        double *eta_Z; eta_Z = new double[NNt*2]; // (PD-z1, PD-z2)
        
        //##### BEGIN:
        for (i_n = 0; i_n < NNt; i_n ++) {
            dose_i = dose[i_n];
            
            //Death -- 10*std_dose
            eta[i_n] = Be[1]/(1.0 + exp(Be[0]*(10.0*dose_i - Be[2])));  // beta_D2/(1 + exp(beta_D1*d)) + gam
                              
            //Tox -- 10*std_dose
            s_ind = NNt*1;
            eta[s_ind + i_n] = Be[4]/(1.0 + exp(Be[3]*(10.0*dose_i - Be[5])));  // beta_T2/(1 + exp(beta_T1*d)) + gam
            
            //PD1
            s_ind = NNt*2;
            eta[s_ind + i_n] = Be[6]*dose_i;  // beta_{PD1}*d + gam
            
            // PD - Z
            s_ind = NNt*3;
            z_1 = Z_obs[i_n];
            if(z_1 >= 0)  //### imaging at t*_1 is done
            {
                eta_Z[i_n] = xi[0] + phi*dose_i; // eta_i1 = xi_1 + phi*dose_1
                
                //##### if imaging at t*_2 is done
                z_2 = Z_obs[NNt + i_n]; // z_2= -1 (no imaging), 0 (PD), 1 (SD), 2 (PR), 3 (CR)
                if(z_2 >= 0) //### imaging at t*_2 is done (meaning at least SD at t*_1 (==> z_1 > 0) & still survived & no PD upto t*_2)
                {
                    eta_Z[NNt + i_n] = xi[1] + phi*dose_i + Alpha[z_1];  // eta_i2 = xi_2 + phi*dose_i + alpha_z1i
                }else{ //## if(z_2 >= 0)
                    eta_Z[NNt + i_n] = 0.0;
                } //if(z_2 >= 0)
            } else{ //# if(z_1 >= 0)
                // no imaging at all
                eta_Z[i_n] = 0.0;
                eta_Z[NNt + i_n] = 0.0;
            }//if(z_1 >= 0)
        } //for (i_n = 0; i_n < NNt; i_n ++) {
        
        if (ind_all == 0) {
            // update gam -- one gam_ij at a time
            fn_update_u_0(NNt, JJ, JJ_1, u_cutoff, Delta, Z_obs, eta, eta_Z, sig2_pi, KK_sum, gam_cur, Inv_Omega);
        }else{
            // update gam -- one gam_i as a vector
            fn_update_u_1(NNt, JJ, JJ_1, u_cutoff, Delta, Z_obs, eta, eta_Z, sig2_pi, KK_sum, gam_cur, Inv_Omega);
        }//if (ind_all == 0) {
        
        delete eta; eta = NULL;
        delete eta_Z; eta_Z = NULL;
    }
    
    
    double fn_abs(double x)
    {
        if (x < 0.0) {
            return -1.0*x;
        }else{
            return x;
        }
    }
    
    double fn_min(double x1, double x2)
    {
        if (x1 < x2) {
            return x1;
        }else{
            return x2;
        }
    }
    
    double fn_max(double x1, double x2)
    {
        if (x1 < x2) {
            return x2;
        }else{
            return x1;
        }
    }
    
    /*
     ###################
     ### SAMPLING FROM TRUNCATED NORMALS
     #####################
     ##### sampling from truncated normal -- N(m, v)1(x_0 < x)
     */
    double fn_sample_trnc_Normal_B(double m, double v, double x_0) // truncated below
    {
        double tmp0, tmp1, x;
        
        tmp0 = pnorm(x_0, m, sqrt(v), 1, 0);  //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        
        GetRNGstate();
        tmp1 = runif(0.0, 1.0)*(1.0 - tmp0);
        PutRNGstate();
        
        x = qnorm(tmp0 + tmp1, m, sqrt(v), 1, 0);  //## qnorm(p, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        
        return x;
    }
    
    // ##### sampling from truncated normal -- N(m, v)1(x < x_1)
    double fn_sample_trnc_Normal_A(double m, double v, double x_1)  // truncated above
    {
        double tmp0, tmp1, x;
        
        tmp0 = pnorm(x_1, m, sqrt(v), 1, 0);  //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        
        GetRNGstate();
        tmp1 = runif(0.0, 1.0)*tmp0;
        PutRNGstate();
        
        x = qnorm(tmp1, m, sqrt(v), 1, 0);  //## qnorm(p, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        
        return x;
    }
    
    // ##### sampling from truncated normal -- N(m, v)1(x_0 < x < x_1)
    double fn_sample_trnc_Normal_BA(double m, double v, double x_0, double x_1)
    {
        double tmp0, tmp1, tmp2, x;
        
        // 1(x_0 < x < x_1)
        tmp0 = pnorm(x_0, m, sqrt(v), 1, 0);  //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        tmp1 = pnorm(x_1, m, sqrt(v), 1, 0);  //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        
        if ((tmp1 - tmp0) > 0.0000001) {
            
            GetRNGstate();
            tmp2 = runif(0.0, 1.0)*(tmp1 - tmp0);
            PutRNGstate();
            
            x = qnorm(tmp0 + tmp2, m, sqrt(v), 1, 0);  //## qnorm(p, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        }else{
            
            GetRNGstate();
            tmp2 = runif(0.0, 1.0);
            PutRNGstate();
            
            x = x_0 + tmp2*fn_abs(x_1 - x_0);
            
            //printf("\n !!!! very close: m=%f, v=%f, x=%f, x0=%f, x1=%f, tmp1-tmp0=%f, a=%d", m, v, x, x_0, x_1, tmp1-tmp0, a);
        }
        
        return x;
    }

    /*
     ###################
     ### Evaluating log-densities of TRUNCATED NORMALS
     #####################
     ##### Evaluating log-densities of truncated normal at x -- x ~ N(m, v)1(x_0 < x)
     */
    double fn_logden_trnc_Normal_B(double x, double m, double v, double x_0)
    {
        //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        //## dnorm(x, mean = 0, sd = 1, log = FALSE)
        double log_den = dnorm(x, m, sqrt(v), 1) - pnorm(x_0, m, sqrt(v), 0, 1);
        return log_den;
    }
    
    /*
     ##### Evaluating log-densities of truncated normal at x -- x ~ N(m, v)1(x < x0)
     */
    double fn_logden_trnc_Normal_A(double x, double m, double v, double x_0)
    {
        //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        //## dnorm(x, mean = 0, sd = 1, log = FALSE)
        double log_den = dnorm(x, m, sqrt(v), 1) - pnorm(x_0, m, sqrt(v), 1, 1);
        return log_den;
    }
    
    //##### Evaluating log-densities of truncated normal at x -- x ~ N(m, v)1(x_0 < x < x_1)
    double fn_logden_trnc_Normal_BA(double x, double m, double v, double x_0, double x_1)
    {
        double tmp0, tmp1, log_den;
        
        tmp0 = pnorm(x_0, m, sqrt(v), 1, 0);  //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        tmp1 = pnorm(x_1, m, sqrt(v), 1, 0);   //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        
        if ((tmp1 - tmp0) < 0.000000001) {  // to avoid a numerical issue
            log_den = dnorm(x, m, sqrt(v), 1) - log(tmp1 - tmp0);
        }else{
            log_den = -100000.0;
        }
        return log_den;
    }
    

    
    /*
     ### evaluate Len_int, Ind_y and res_y -- outcome j
     ### SS_j: (Q_j+1)-dim vector -- fixed with s_{j0}=0 and s_{j, Q_j}=C_j -- 0, 1, 2, ...., Q_j
     ##  NN_t: # of patients
     ##  Q_j: the number of intervals
     ##  YY: (NN_t*JJ)-dim matrix
     
     ###### Len_int_j: Q_max*J matrix
     ##  Len_int_j: length of intervals -- Q_j-dim vector
     ### Len_int_{j, q} = ss_{j, q+1} - ss_{j, q}
     ### e_{i, j} = q <==> s_{j, q} <= y_{i,j} < s_{j, q+1}
     ### res_y_{i, j} = y_obs_{i, j} - s_{j, e_{i, j}}
     
     ##  Ind_y_j = e_j:  indicators where Y_{ij}^o lies in the interval -- NNt-dim
     ##  res_y_j:  (Y_{iD}^o - s_{j, e_{ij}}) --- NNt-dim
     */
    void fn_compute_Len_Ind_res_j(int NNt, int Q_max, int Q_j, double *YY, double *SS, double *Len_int, int *Ind_y, double *res_y, int ind_j)
    {
        int i_q, i_n, e_ij;
        int s_ind = NNt*ind_j;       // starting indicator  -- for y, Ind_y & res_y_j
        int s_ind_1 = Q_max*ind_j;   // starting indicator  -- for Len_int
        int s_ind_2 = (Q_max + 1)*ind_j;   // starting indicator  -- for Len_int
        double y_ij;
        
        //### compute Len_{jq}= s_{j, q+1} - s_{j,q}, q=0, ..., Q_j-1
        for (i_q = 0; i_q < Q_j; i_q ++) {
            Len_int[s_ind_1 + i_q] = SS[s_ind_2 + i_q + 1] - SS[s_ind_2 + i_q];
        }//for (i_q = 0; i_q < Q_j; i_q ++) {
        
        // compute Ind_y_j & res_y_j
        for (i_n=0; i_n < NNt; i_n++)
        {
            y_ij = YY[s_ind + i_n];
            
            //## where Y_ij lies in
            // ###  e_ij = q <=> Y_ij is in (s_q, s_{q + 1}], e_ij = 0, 1, 2, ..., (Q_j-1)
            e_ij = -1;
            for (i_q = 0; i_q < Q_j; i_q++) {
                if ((y_ij > SS[s_ind_2 + i_q])&&(y_ij <= SS[s_ind_2 + i_q + 1])) {
                    e_ij = i_q;
                    i_q = Q_j; // exit the for loop
                }
            }//for (i_q = 0; i_q < Q_j; i_q++) {
            
            if (e_ij < 0) {
                printf("\n Look y_ij=%f, e_ij=%d", y_ij, e_ij);
                e_ij = Q_j - 1;
            }//if (e_ij < 0) {
            
            Ind_y[s_ind + i_n] = e_ij;
            res_y[s_ind + i_n] = y_ij - SS[s_ind_2 + e_ij];
        } //## for(i_n in 1:NN_t)
    }
    
    /*
     ########## update s_jq, q=1, 2, ..., (Q_j-1) with s_j0=0 and s_{j, Q_j}=C_j fixed
     ### (ss_0, ss_1, ss_2)=(s_{j, q-1}, s_{j, q}, s_{j, q+1})
     ### lam_0 = lam_{j, q-1}: baseline harzard for [s_{j, q-1}, s_{j, q}) & lam_1 = lam_{j, q}: baseline harzard for [s_{j, q}, s_{j, q + 1})
     
     ###  NN_t: # of patients
     ### eta_ij: dose + fraility part
     
     prob_cur = fn_eval_ss_jq(NNt, Q_max, Q_j, i_q, Lam[s_ind_1 + i_q - 1], Lam[s_ind_1 + i_q], YY, eta_j, SS[s_ind_1 + i_q - 1], SS[s_ind_1 + i_q], SS[s_ind_1 + i_q + 1], ind_j);
     */
    double fn_eval_ss_jq(int NNt, int Q_max, int QQ_j, int i_q, double lam_0, double lam_1, double *YY, double *eta_j, double ss_0, double ss_1, double ss_2, int ind_j)
    {
        int i_n;
        int s_ind = ind_j*NNt; // staring ind for YY
        
        double len_0 = ss_1 - ss_0;
        double len_1 = ss_2 - ss_1;
        
        double y_ij, prob = 0.0;
        
        //## likelihood
        for (i_n=0; i_n < NNt; i_n++) {
            
            y_ij = YY[s_ind + i_n];
            
            if (ss_0 < y_ij) {
                if (ss_1 <= y_ij) {
                    prob = prob - exp(eta_j[i_n] + lam_0)*len_0;         // ss_0 < ss_1 <= y_ij
                }else{
                    prob = prob - exp(eta_j[i_n] + lam_0)*(y_ij - ss_0); // ss_0 < y_ij < ss_1
                }
            }//if (ss_0 <= y_ij) {
            
            if (ss_1 < y_ij) {
                if (ss_2 <= y_ij) {
                    prob = prob - exp(eta_j[i_n] + lam_1)*len_1;          // ss_1 < ss_2 <= y_ij
                }else{
                    prob = prob - exp(eta_j[i_n] + lam_1)*(y_ij - ss_1);  // ss_1 < y_ij < ss_2
                }
            }//if (ss_1 <= y_ij) {
        } //## for(i_n in 1:NNt)
        
        return prob;
    }

    
    /*
     ### evaluate Len_int, Ind_y and res_y -- outcome j
     ### SS_j: (Q_j+1)-dim vector -- fixed with s_{j0}=0 and s_{j, Q_j}=C_j -- 0, 1, 2, ...., Q_j
     ##  NN_t: # of patients
     ##  Q_j: the number of intervals
     ##  YY: (NN_t*JJ)-dim matrix
     
     ###### Len_int_j: Q_max*J matrix
     ##  Len_int_j: length of intervals -- Q_j-dim vector
     ### Len_int_{j, q} = ss_{j, q+1} - ss_{j, q}
     ### e_{i, j} = q <==> s_{j, q} <= y_{i,j} < s_{j, q+1}
     ### res_y_{i, j} = y_obs_{i, j} - s_{j, e_{i, j}}
     
     ##  Ind_y_j = e_j:  indicators where Y_{ij}^o lies in the interval -- NNt-dim
     ##  res_y_j:  (Y_{iD}^o - s_{j, e_{ij}}) --- NNt-dim
     */
    void fn_update_s_j(int NNt, int Q_max, int Q_j, double *YY, double *eta_j, double *Lam, double *SS, int ind_j)
    {
        int i_q;
        int s_ind_1 = (Q_max + 1)*ind_j;    // starting indicator  -- for SS
        int s_ind_2 = Q_max*ind_j; // starting indicator for lam
        
        
        double prob_cur, prob_pro, u, s_jq_pro;
        
        //## one at a time, s_{j, q}
        for (i_q = 1; i_q < Q_j; i_q++) {
            
            //### make a proposal
            //# random walk
            GetRNGstate();
            s_jq_pro = SS[s_ind_1 + i_q - 1] + runif(0.0, 1.0)*(SS[s_ind_1 + i_q + 1] - SS[s_ind_1 + i_q - 1]);
            PutRNGstate();
            
            //printf("\n\n i_q=%d, s_cur=%f, s_pro=%f, s_dwn=%f, s_up=%f", i_q, SS[s_ind_1 + i_q], s_jq_pro, SS[s_ind_1 + i_q - 1], SS[s_ind_1 + i_q + 1]);
            
            //## evaluate prob under the current and proposed values
            prob_cur = fn_eval_ss_jq(NNt, Q_max, Q_j, i_q, Lam[s_ind_2 + i_q - 1], Lam[s_ind_2 + i_q], YY, eta_j, SS[s_ind_1 + i_q - 1], SS[s_ind_1 + i_q], SS[s_ind_1 + i_q + 1], ind_j);
            prob_pro = fn_eval_ss_jq(NNt, Q_max, Q_j, i_q, Lam[s_ind_2 + i_q - 1], Lam[s_ind_2 + i_q], YY, eta_j, SS[s_ind_1 + i_q - 1], s_jq_pro, SS[s_ind_1 + i_q + 1], ind_j);
            
            //printf("\n p_c=%f, p_p=%f", prob_cur, prob_pro);
            
            //Let's do M-H
            GetRNGstate();
            u = runif(0.0, 1.0);
            PutRNGstate();
            
            //### Accept?
            if(log(u) < (prob_pro - prob_cur))
            {
                SS[s_ind_1 + i_q] = s_jq_pro;
            } //## if(log(runif(1, 0, 1)) < (prob_pro - prob_cur))
        } //## for(i_q in 1:QQ)
    }
    

    /*
     ### evaluate the piecewise linear part of baseline hazard for each patient -- outcome j
     ##  KK_j = sum^{e_ij-1} exp(lam_jq)*len_int[q] + lam_j[e_ij]*res_y_j[i_n])  ==> KK_sum: (NNt*JJ)-dim matrix
     ##  NN_t: # of patients
     ##  Q_j: the number of intervals
     
     ###### lam & Len_int_j: Q_max*J matrix
     ##  lam_j: baseline hazard -- Q_j-dim vector
     ##  Len_int_j: length of intervals -- Q_j-dim vector
     
     ##  Ind_y_j:  indicators where Y_{ij}^o lies in the interval -- NNt-dim
     ##  res_y_j:  (Y_{iD}^o - s_{j, e_{ij}}) --- NNt-dim
     
     fn_compute_KK_j(NNt, Q_max, QQ[ind_j], lam_cur, Len_int, Ind_y, res_y, KK_sum, ind_j);
     */
    void fn_compute_KK_j(int NNt, int Q_max, int Q_j, double *lam, double *Len_int, int *Ind_y, double *res_y, double *KK_sum, int ind_j)
    {
        int i_q, i_n, e_ij;
        int s_ind = NNt*ind_j;       // starting indicator  -- for y
        int s_ind_1 = Q_max*ind_j;   // starting indicator  -- for lambda
        
        double tmp_sum;
        double *tmp_lam_len; tmp_lam_len = new double[Q_j];
        
        //### exp(lam_{jq})*(s_{jq} - s_{j,q-1}), q=1, ..., Q_j
        for (i_q=0; i_q < Q_j; i_q++) {
            tmp_lam_len[i_q] = exp(lam[s_ind_1 + i_q])*Len_int[s_ind_1 + i_q];
        }
        
        for (i_n=0; i_n < NNt; i_n++)
        {
            //## where Y_ij lies in
            e_ij = Ind_y[s_ind + i_n]; // ###  e_ij = q-1 <=> Y_ij is in (s_{q-1}, s_q), e_ij = 0, 1, 2, ..., (Q_j-1)
            
            tmp_sum = 0.0;
            if (e_ij > 0) {
                for (i_q = 0; i_q < e_ij; i_q ++) {
                    tmp_sum = tmp_sum + tmp_lam_len[i_q];
                }
            } //if (e_ij > 0) {
            
            KK_sum[s_ind + i_n] = tmp_sum + exp(lam[s_ind_1 + e_ij])*res_y[s_ind + i_n];
        } //## for(i_n in 1:NN_t)
        
        delete tmp_lam_len; tmp_lam_len= NULL;
    }
    
    /*
     ########## update Lamda_j, j=D, T, PD
     ## lam_1 ~ N(lam_0, sig2_0)
     ## lam_q ~ N(lam_{q-1}, sig2), q=2, 3, \ldots, Q  -- Q_max*J matrix
     
     ###### lam & Len_int_j: Q_max*J matrix
     ##  lam_j: baseline hazard -- exp(lam_j)  -- Q_j-dim vector
     ##  Len_int_j: length of intervals -- Q_j-dim vector
     
     ##  NN_t: # of patients
     ##  Delta_D:  binary indicators where Y_{iD}^o is observed (observed: 1, censored: 0)
     ### Delta_D = ind_PD
     ###  where if PD is observed from symptoms and signs ==> if so, then ind_PD = 1
     
     #### Ind_y, res_y, Delta: NNt*JJ-matrix
     
     ### eta_ij: dose + fraility part
     */
    double fn_eval_lam_jq(int NNt, int Q_max, int QQ_j, int i_q, double *Len_int, int *Ind_y, double *res_y, int *Delta, double *eta_j, double *lam, double sig2_j, double lam_jq, double lam_0j, double sig2_0j, int ind_j)
    {
        int i_n, e_ij;
        int s_ind = ind_j*NNt; // staring ind
        int s_ind_1 = ind_j*Q_max;
        
        double prob;
        
        // CAUTION: i_q=0, ..., Q-1
        //#### prior for one below
        if(i_q == 0)  // in fact, lam1
        {
            //## lam_{j1} ~ N(lam_{j0}, sig2_{j0})  ==> this is lam_0 in C
            prob = -pow(lam_jq - lam_0j, 2.0)/2.0/sig2_0j;
        }else{
            //## lam_q ~ N(lam_{q-1}, sig2), q=2, 3, 4... Q
            prob = -pow(lam_jq - lam[s_ind_1 + i_q - 1], 2.0)/2.0/sig2_j;
        } //## if(i_q == 1)
        
        //#### prior for one above
        //## if it is not the last one, lam_{q+1} ~ N(lam_q, sig2), q=0, 1, 2, 3, 4... Q-1
        if (i_q < (QQ_j - 1)) {
            prob = prob - pow(lam_jq - lam[s_ind_1 + i_q + 1], 2.0)/2.0/sig2_j;
        }
        
        
        //## likelihood
        for (i_n=0; i_n < NNt; i_n++) {
            
            //## where Y_ij lies in
            e_ij = Ind_y[s_ind + i_n]; //###  e_ij = q <=> Y_ij is in (s_q, s_{q+1})
            
            //### Y^o_{ij} in (s_q, s_{q+1})
            if(e_ij == i_q)
            {
                prob = prob + 1.0*Delta[s_ind + i_n]*lam_jq - exp(eta_j[i_n] + lam_jq)*res_y[s_ind + i_n];  // res_y = y_obs - s_e
            } //# if(e_ij == i_q)
            
            //### Y^o_{ij} > s_{q+1}
            if(e_ij > i_q)
            {
                prob = prob - exp(eta_j[i_n] + lam_jq)*Len_int[s_ind_1 + i_q]; // Len_q = s_{q+1} - s_q
            } //# if(e_ij > i_q)
            
        } //## for(i_n in 1:NNt)
        
        return prob;
    }
    
    /*
     ###### lam & Len_int_j: Q_max*J matrix
     ##  lam_j: baseline hazard -- exp(lam_j)  -- Q_j-dim vector
     ##  Len_int_j: length of intervals -- Q_j-dim vector
     */
    
    void fn_update_lam_j(int NNt, int Q_max, int QQ_j, double *dose, int *Delta, double *Len_int, int *Ind_y, double *res_y, double *eta_j,
                         double *lam_cur, double sig2_j, double lam_0j, double sig2_0j, int ind_j, int *Accpt_cnt_lam, double *v2_MH_lam)
    {
        int i_q;
        int s_ind_1 = Q_max*ind_j;    // starting indicator  -- for lambda
        
        double prob_cur, prob_pro, u, lam_jq_pro;
        
        //## one at a time, lam_{jq}
        for (i_q = 0; i_q < QQ_j; i_q++) {
            
            //### make a proposal
            //# random walk
            GetRNGstate();
            lam_jq_pro = lam_cur[s_ind_1 + i_q] + rnorm(0.0, sqrt(v2_MH_lam[s_ind_1 + i_q]));
            PutRNGstate();
            
            //## evaluate prob under the current and proposed values
            prob_cur = fn_eval_lam_jq(NNt, Q_max, QQ_j, i_q, Len_int, Ind_y, res_y, Delta, eta_j, lam_cur, sig2_j, lam_cur[s_ind_1 + i_q], lam_0j, sig2_0j, ind_j);
            prob_pro = fn_eval_lam_jq(NNt, Q_max, QQ_j, i_q, Len_int, Ind_y, res_y, Delta, eta_j, lam_cur, sig2_j, lam_jq_pro, lam_0j, sig2_0j, ind_j);
            
            //printf("\n i_q=%d, lam_c=%f, lam_p=%f, p_cur=%f, p_pro=%f", i_q, lam_cur[s_ind_1 + i_q], lam_jq_pro, prob_cur, prob_pro);
            
            //Let's do M-H
            GetRNGstate();
            u = runif(0.0, 1.0);
            PutRNGstate();
            
            //### Accept?
            if(log(u) < (prob_pro - prob_cur))
            {
                lam_cur[s_ind_1 + i_q] = lam_jq_pro;
                Accpt_cnt_lam[s_ind_1 + i_q] = Accpt_cnt_lam[s_ind_1 + i_q] + 1;
            } //## if(log(runif(1, 0, 1)) < (prob_pro - prob_cur))
        } //## for(i_q in 1:QQ)
    }

    
    /*
     // Update lambda for all j=D, T, PD and update KK_j accordingly
     ##  KK_j = sum^{e_ij-1} exp(lam_jq)*len_int[q] + lam_j[e_ij]*res_y_j[i_n])
     ##  Ind_y_j:  indicators where Y_{ij}^o lies in the interval -- NNt-dim
     ##  res_y_j:  (Y_{iD}^o - s_{j, e_{ij}}) --- NNt_dim
     ##  KK_j, Ind_y_j, res_y_j: NNt*J matrix
     
     ##  NN_t: # of patients
     ##  Q_j: the number of intervals
     
     ###### lam & Len_int_j: Q_max*J matrix
     ##  lam_j: baseline hazard -- exp(lam_j)  -- Q_j-dim vector
     ##  Len_int_j: length of intervals -- Q_j-dim vector
     */
    void fn_update_lam_SS(int NNt, double *dose, double *YY, double *Be, double *gam, int Q_max, int *QQ, int *Delta,
                          double *Lam_cur, double *sig2, double *lam_0, double *sig2_0, double *KK_sum,
                          double *SS_cur, double *Len_int, int *Ind_y, double *res_y, int *Accpt_cnt_lam, double *v2_MH_lam)
    {
        int ind_j, i_n, s_ind;
        double *eta_j; eta_j = new double[NNt];
        
        //##### BEGIN: s (baseline hazard cutpoints) for death -- 10*std_dose
        ind_j = 0;
        s_ind = ind_j*NNt;
        for (i_n = 0; i_n < NNt; i_n ++) {
            eta_j[i_n] = Be[1]/(1.0 + exp(Be[0]*(10.0*dose[i_n] - Be[2]))) + gam[s_ind + i_n];
        }
        
        //### update SS_D
        //fn_update_s_j(NNt, Q_max, QQ[ind_j], YY, eta_j, Lam_cur, SS_cur, ind_j);
        
        // update Len_int, Ind_y, res_y
        //fn_compute_Len_Ind_res_j(NNt, Q_max, QQ[ind_j], YY, SS_cur, Len_int, Ind_y, res_y, ind_j);

        //### update lamda_D
        fn_update_lam_j(NNt, Q_max, QQ[ind_j], dose, Delta, Len_int, Ind_y, res_y, eta_j, Lam_cur, sig2[ind_j], lam_0[ind_j], sig2_0[ind_j], ind_j, Accpt_cnt_lam, v2_MH_lam);
        
        // update KK_D
        fn_compute_KK_j(NNt, Q_max, QQ[ind_j], Lam_cur, Len_int, Ind_y, res_y, KK_sum, ind_j);
        //##### END: s (baseline hazard cutpoints) for death
        
        //##### BEGIN: s (baseline hazard cutpoints) for tox  -- 10*std_dose
        ind_j = 1;
        s_ind = ind_j*NNt;
        for (i_n = 0; i_n < NNt; i_n ++) {
            eta_j[i_n] = Be[4]/(1.0 + exp(Be[3]*(10.0*dose[i_n] - Be[5]))) + gam[s_ind + i_n];
        }
        
        //### update SS_T
        //fn_update_s_j(NNt, Q_max, QQ[ind_j], YY, eta_j, Lam_cur, SS_cur, ind_j);
        
        // update Len_int, Ind_y, res_y
        //fn_compute_Len_Ind_res_j(NNt, Q_max, QQ[ind_j], YY, SS_cur, Len_int, Ind_y, res_y, ind_j);
        
        //### update lamda_T
        fn_update_lam_j(NNt, Q_max, QQ[ind_j], dose, Delta, Len_int, Ind_y, res_y, eta_j, Lam_cur, sig2[ind_j], lam_0[ind_j], sig2_0[ind_j], ind_j, Accpt_cnt_lam, v2_MH_lam);
        
        // update KK_T
        fn_compute_KK_j(NNt, Q_max, QQ[ind_j], Lam_cur, Len_int, Ind_y, res_y, KK_sum, ind_j);
        //##### END: s (baseline hazard cutpoints) for TOX
        
        //##### BEGIN: s (baseline hazard cutpoints) for PD
        ind_j = 2;
        s_ind = ind_j*NNt;
        for (i_n = 0; i_n < NNt; i_n ++) {
            eta_j[i_n] = Be[6]*dose[i_n] + gam[s_ind + i_n];
        }
        
        //### update SS_PD
        //fn_update_s_j(NNt, Q_max, QQ[ind_j], YY, eta_j, Lam_cur, SS_cur, ind_j);
        
        // update Len_int, Ind_y, res_y
        //fn_compute_Len_Ind_res_j(NNt, Q_max, QQ[ind_j], YY, SS_cur, Len_int, Ind_y, res_y, ind_j);
        
        //### update lamda_PD
        fn_update_lam_j(NNt, Q_max, QQ[ind_j], dose, Delta, Len_int, Ind_y, res_y, eta_j, Lam_cur, sig2[ind_j], lam_0[ind_j], sig2_0[ind_j], ind_j, Accpt_cnt_lam, v2_MH_lam);
        
        // update KK_PD
        fn_compute_KK_j(NNt, Q_max, QQ[ind_j], Lam_cur, Len_int, Ind_y, res_y, KK_sum, ind_j);
        //##### END: s (baseline hazard cutpoints) for PD
    
        delete eta_j; eta_j= NULL;
    }

    
    
    /*
     ### evaluate Len_int, Ind_y and res_y -- outcome j
     ### SS_j: (Q_j+1)-dim vector -- fixed with s_{j0}=0 and s_{j, Q_j}=C_j -- 0, 1, 2, ...., Q_j
     ##  NN_t: # of patients
     ##  Q_j: the number of intervals
     ##  YY: (NN_t*JJ)-dim matrix
     
     ###### Len_int_j: Q_max*J matrix
     ##  Len_int_j: length of intervals -- Q_j-dim vector
     ### Len_int_{j, q} = ss_{j, q+1} - ss_{j, q}
     ### e_{i, j} = q <==> s_{j, q} <= y_{i,j} < s_{j, q+1}
     ### res_y_{i, j} = y_obs_{i, j} - s_{j, e_{i, j}}
     
     ##  Ind_y_j = e_j:  indicators where Y_{ij}^o lies in the interval -- NNt-dim
     ##  res_y_j:  (Y_{iD}^o - s_{j, e_{ij}}) --- NNt-dim
     */
    void fn_update_s_j_1(int NNt, int Q_max, int Q_j, double *YY, double *eta_j, double *Lam, double *SS, int ind_j)
    {
        int i_q;
        int s_ind_1 = (Q_max + 1)*ind_j;    // starting indicator  -- for SS
        int s_ind_2 = Q_max*ind_j; // starting indicator for lam

        double sq_v = 3.0;
        
        if (ind_j == 3) {
            sq_v = sq_v*2;
        }
        
        double prob_cur, prob_pro, u, s_jq_pro;
        
        //## one at a time, s_{j, q}
        for (i_q = 1; i_q < Q_j; i_q++) {
            
            //### make a proposal from a truncated normal
            GetRNGstate();
            s_jq_pro = SS[s_ind_1 + i_q] + rnorm(0.0, sq_v);
            PutRNGstate();
            
            // satisfy the conditions.
            if ((s_jq_pro > SS[s_ind_1 + i_q -1]) && (s_jq_pro < SS[s_ind_1 + i_q + 1])) {
                
                //fn_sample_trnc_Normal_BA(SS[s_ind_1 + i_q], v, SS[s_ind_1 + i_q - 1], SS[s_ind_1 + i_q + 1]);
                
                //## evaluate prob under the current and proposed values
                prob_cur = fn_eval_ss_jq(NNt, Q_max, Q_j, i_q, Lam[s_ind_2 + i_q - 1], Lam[s_ind_2 + i_q], YY, eta_j, SS[s_ind_1 + i_q - 1], SS[s_ind_1 + i_q], SS[s_ind_1 + i_q + 1], ind_j);
                prob_pro = fn_eval_ss_jq(NNt, Q_max, Q_j, i_q, Lam[s_ind_2 + i_q - 1], Lam[s_ind_2 + i_q], YY, eta_j, SS[s_ind_1 + i_q - 1], s_jq_pro, SS[s_ind_1 + i_q + 1], ind_j);
                
                //Let's do M-H
                GetRNGstate();
                u = runif(0.0, 1.0);
                PutRNGstate();
                
                //### Accept?
                if(log(u) < (prob_pro - prob_cur))
                {
                    SS[s_ind_1 + i_q] = s_jq_pro;
                } //## if(log(runif(1, 0, 1)) < (prob_pro - prob_cur))
            }
            
        } //## for(i_q in 1:QQ)
    }
    
    
    /*
     ### evaluate the piecewise linear part of baseline hazard for each patient -- outcome j
     ##  KK_j = sum^{e_ij-1} exp(lam_jq)*len_int[q] + lam_j[e_ij]*res_y_j[i_n])  ==> KK_sum: (NNt*JJ)-dim matrix
     ##  NN_t: # of patients
     ##  Q_j: the number of intervals
     
     ###### lam & Len_int_j: Q_max*J matrix
     ##  lam_j: baseline hazard -- Q_j-dim vector
     ##  Len_int_j: length of intervals -- Q_j-dim vector
     
     ##  Ind_y_j:  indicators where Y_{ij}^o lies in the interval -- NNt-dim
     ##  res_y_j:  (Y_{iD}^o - s_{j, e_{ij}}) --- NNt-dim
     
     fn_compute_KK_j(NNt, Q_max, QQ[ind_j], lam_cur, Len_int, Ind_y, res_y, KK_sum, ind_j);
     */
    void fn_compute_KK_j_1(int NNt, int Q_max, int Q_j, double *lam, double *Len_int, int *Ind_y, double *res_y, double *KK_sum, int ind_j)
    {
        int i_q, i_n, e_ij;
        int s_ind = NNt*ind_j;       // starting indicator  -- for y
        int s_ind_1 = Q_max*ind_j;   // starting indicator  -- for lambda
        
        double tmp_sum;
        double *tmp_lam_len; tmp_lam_len = new double[Q_j];
        
        //### exp(lam_{jq})*(s_{jq} - s_{j,q-1}), q=1, ..., Q_j
        for (i_q=0; i_q < Q_j; i_q++) {
            tmp_lam_len[i_q] = exp(lam[i_q])*Len_int[s_ind_1 + i_q];
        }
        
        for (i_n=0; i_n < NNt; i_n++)
        {
            //## where Y_ij lies in
            e_ij = Ind_y[s_ind + i_n]; // ###  e_ij = q-1 <=> Y_ij is in (s_{q-1}, s_q), e_ij = 0, 1, 2, ..., (Q_j-1)
            
            tmp_sum = 0.0;
            if (e_ij > 0) {
                for (i_q = 0; i_q < e_ij; i_q ++) {
                    tmp_sum = tmp_sum + tmp_lam_len[i_q];
                }
            } //if (e_ij > 0) {
            
            KK_sum[i_n] = tmp_sum + exp(lam[e_ij])*res_y[s_ind + i_n];
        } //## for(i_n in 1:NN_t)
        
        delete tmp_lam_len; tmp_lam_len= NULL;
    }
    
    
    /*
     ########## update Lamda_j, j=D, T, PD
     ## lam_1 ~ N(lam_0, sig2_0)
     ## lam_q ~ N(lam_{q-1}, sig2), q=2, 3, \ldots, Q  -- Q_max*J matrix
     
     ###### lam & Len_int_j: Q_max*J matrix
     ##  lam_j: baseline hazard -- exp(lam_j)  -- Q_j-dim vector
     ##  Len_int_j: length of intervals -- Q_j-dim vector
     
     ##  NN_t: # of patients
     ##  Delta_D:  binary indicators where Y_{iD}^o is observed (observed: 1, censored: 0)
     ### Delta_D = ind_PD
     ###  where if PD is observed from symptoms and signs ==> if so, then ind_PD = 1
     
     #### Ind_y, res_y, Delta: NNt*JJ-matrix
     
     ### eta_ij: dose + fraility part
     */
    
    /*
     ###### lam & Len_int_j: Q_max*J matrix
     ##  lam_j: baseline hazard -- exp(lam_j)  -- Q_j-dim vector
     ##  Len_int_j: length of intervals -- Q_j-dim vector
     */
    void fn_update_lam_j_all(int NNt, int Q_max, int QQ_j, double *dose, int *Delta, double *Len_int, int *Ind_y, double *res_y, double *eta_j,
                             double *lam_cur, double sig2_j, double lam_0j, double sig2_0j,
                             double *KK_sum_cur, int ind_j)
    {
        int i_q, i_n, e_ij;
        int s_ind = NNt*ind_j;       // starting indicator  -- for y
        int s_ind_1 = Q_max*ind_j;    // starting indicator  -- for lambda
        
        double prob_cur, prob_pro, u, tmp_pro, tmp_cur;
        double sd_MH = 0.15;
        
        double *lam_j_pro, *KK_sum_j_pro;
        lam_j_pro = new double[QQ_j];
        KK_sum_j_pro = new double[NNt];
        
        prob_cur = 0.0;
        prob_pro = 0.0;
        
        //## propose all lam_{jq}
        for (i_q = 0; i_q < QQ_j; i_q++) {
            
            //### make a proposal- random walk
            GetRNGstate();
            lam_j_pro[i_q] = lam_cur[s_ind_1 + i_q] + rnorm(0.0, sd_MH);
            PutRNGstate();
            
            // CAUTION: i_q=0, ..., Q-1
            //#### prior for one below
            if(i_q == 0)  // in fact, lam1
            {
                //## lam_{j1} ~ N(lam_{j0}, sig2_{j0})  ==> this is lam_0 in C
                prob_cur = prob_cur - pow(lam_cur[s_ind_1 + i_q] - lam_0j, 2.0)/2.0/sig2_0j;
                prob_pro = prob_pro - pow(lam_j_pro[i_q] - lam_0j, 2.0)/2.0/sig2_0j;
            }else{
                //## lam_q ~ N(lam_{q-1}, sig2), q=2, 3, 4... Q
                prob_cur = prob_cur - pow(lam_cur[s_ind_1 + i_q] - lam_cur[s_ind_1 + i_q - 1], 2.0)/2.0/sig2_0j;
                prob_pro = prob_pro - pow(lam_j_pro[i_q] - lam_j_pro[i_q - 1], 2.0)/2.0/sig2_j;
            } //## if(i_q == 1)
        }//for (i_q = 0; i_q < QQ_j; i_q++) {
        
        // compute KK_sum under proposed lam set
        fn_compute_KK_j_1(NNt, Q_max, QQ_j, lam_j_pro, Len_int, Ind_y, res_y, KK_sum_j_pro, ind_j);
        
        // Like
        for (i_n = 0; i_n < NNt; i_n ++) {
            //## where Y_ij lies in
            e_ij = Ind_y[s_ind + i_n]; // ###  e_ij = q-1 <=> Y_ij is in (s_{q-1}, s_q), e_ij = 0, 1, 2, ..., (Q_j-1)
            
            //## evaluate like -- current
            tmp_cur = 1.0*Delta[s_ind + i_n]*lam_cur[s_ind_1 + e_ij] - exp(eta_j[i_n])*KK_sum_cur[s_ind + i_n];
            
            //## evaluate like -- proposed
            tmp_pro = 1.0*Delta[s_ind + i_n]*lam_j_pro[e_ij] - exp(eta_j[i_n])*KK_sum_j_pro[i_n];
            
            prob_pro = prob_pro + tmp_pro - tmp_cur;
        } //## for(i_n in 1:NNt)
        
        
        //Let's do M-H
        GetRNGstate();
        u = runif(0.0, 1.0);
        PutRNGstate();
        
        //### Accept?
        if(log(u) < (prob_pro - prob_cur))
        {
            //printf("\n accept");
            
            for (i_q = 0; i_q < QQ_j; i_q++) {
                lam_cur[s_ind_1 + i_q] = lam_j_pro[i_q];
            }
            
            for (i_n = 0; i_n < NNt; i_n ++) {
                KK_sum_cur[s_ind + i_n] = KK_sum_j_pro[i_n];
            }
        } //## if(log(runif(1, 0, 1)) < (prob_pro - prob_cur))
        
        delete[] lam_j_pro; lam_j_pro = NULL;
        delete[] KK_sum_j_pro; KK_sum_j_pro = NULL;
    }
    
    
    
    /*
     // Update lambda for all j=D, T, PD and update KK_j accordingly
     ##  KK_j = sum^{e_ij-1} exp(lam_jq)*len_int[q] + lam_j[e_ij]*res_y_j[i_n])
     ##  Ind_y_j:  indicators where Y_{ij}^o lies in the interval -- NNt-dim
     ##  res_y_j:  (Y_{iD}^o - s_{j, e_{ij}}) --- NNt_dim
     ##  KK_j, Ind_y_j, res_y_j: NNt*J matrix
     
     ##  NN_t: # of patients
     ##  Q_j: the number of intervals
     
     ###### lam & Len_int_j: Q_max*J matrix
     ##  lam_j: baseline hazard -- exp(lam_j)  -- Q_j-dim vector
     ##  Len_int_j: length of intervals -- Q_j-dim vector
     */
    void fn_update_lam_SS_1(int NNt, double *dose, double *YY, double *Be, double *gam, int Q_max, int *QQ, int *Delta,
                          double *Lam_cur, double *sig2, double *lam_0, double *sig2_0, double *KK_sum,
                          double *SS_cur, double *Len_int, int *Ind_y, double *res_y)
    {
        int ind_j, i_n, s_ind;
        double *eta_j; eta_j = new double[NNt];
        
        //##### BEGIN: s (baseline hazard cutpoints) for death -- 10*std_dose
        ind_j = 0;
        s_ind = ind_j*NNt;
        for (i_n = 0; i_n < NNt; i_n ++) {
            eta_j[i_n] = Be[1]/(1.0 + exp(Be[0]*(10.0*dose[i_n] - Be[2]))) + gam[s_ind + i_n];
        }
        
        //### update SS_D
        //fn_update_s_j_1(NNt, Q_max, QQ[ind_j], YY, eta_j, Lam_cur, SS_cur, ind_j);
        
        // update Len_int, Ind_y, res_y
        //fn_compute_Len_Ind_res_j(NNt, Q_max, QQ[ind_j], YY, SS_cur, Len_int, Ind_y, res_y, ind_j);
        
        //### update lamda_D
        fn_update_lam_j_all(NNt, Q_max, QQ[ind_j], dose, Delta, Len_int, Ind_y, res_y, eta_j, Lam_cur, sig2[ind_j], lam_0[ind_j], sig2_0[ind_j], KK_sum, ind_j);
        //##### END: s (baseline hazard cutpoints) for death
        
        //##### BEGIN: s (baseline hazard cutpoints) for tox -- 10*std_dose
        ind_j = 1;
        s_ind = ind_j*NNt;
        for (i_n = 0; i_n < NNt; i_n ++) {
            eta_j[i_n] = Be[4]/(1.0 + exp(Be[3]*(10.0*dose[i_n] - Be[5]))) + gam[s_ind + i_n];
        }
        
        //### update SS_T
        //fn_update_s_j_1(NNt, Q_max, QQ[ind_j], YY, eta_j, Lam_cur, SS_cur, ind_j);
        
        // update Len_int, Ind_y, res_y
        //fn_compute_Len_Ind_res_j(NNt, Q_max, QQ[ind_j], YY, SS_cur, Len_int, Ind_y, res_y, ind_j);
        
        //### update lamda_T
        fn_update_lam_j_all(NNt, Q_max, QQ[ind_j], dose, Delta, Len_int, Ind_y, res_y, eta_j, Lam_cur, sig2[ind_j], lam_0[ind_j], sig2_0[ind_j], KK_sum, ind_j);
        //##### END: s (baseline hazard cutpoints) for TOX
        
        //##### BEGIN: s (baseline hazard cutpoints) for PD
        ind_j = 2;
        s_ind = ind_j*NNt;
        for (i_n = 0; i_n < NNt; i_n ++) {
            eta_j[i_n] = Be[6]*dose[i_n] + gam[s_ind + i_n];
        }
        
        //### update SS_PD
        //fn_update_s_j_1(NNt, Q_max, QQ[ind_j], YY, eta_j, Lam_cur, SS_cur, ind_j);
        
        // update Len_int, Ind_y, res_y
        //fn_compute_Len_Ind_res_j(NNt, Q_max, QQ[ind_j], YY, SS_cur, Len_int, Ind_y, res_y, ind_j);
        
        //### update lamda_PD
        fn_update_lam_j_all(NNt, Q_max, QQ[ind_j], dose, Delta, Len_int, Ind_y, res_y, eta_j, Lam_cur, sig2[ind_j], lam_0[ind_j], sig2_0[ind_j], KK_sum, ind_j);
        //##### END: s (baseline hazard cutpoints) for PD
        
        delete eta_j; eta_j= NULL;
    }

    
    void fn_make_propsal_trncN(double th_cur, double *th_pro, double v, int trnc_sign, double *A_cur, double *A_pro)
    {
        if (trnc_sign == (-1)) {
            // (trnc_sign=-1) <=> be < 0 ===> truncated from above
            *th_pro = fn_sample_trnc_Normal_A(th_cur, v, 0.0);
            
            // transition prob den
            *A_cur = *A_cur + fn_logden_trnc_Normal_A(*th_pro, th_cur, v, 0.0);
            *A_pro = *A_pro + fn_logden_trnc_Normal_A(th_cur, *th_pro, v, 0.0);
        }
        
        if (trnc_sign == 1)
        {
            // (trnc_sign = 1) <=> be > 0 ===> truncated from below
            *th_pro = fn_sample_trnc_Normal_B(th_cur, v, 0.0);
            
            // transition prob den
            *A_cur = *A_cur + fn_logden_trnc_Normal_B(*th_pro, th_cur, v, 0.0);
            *A_pro = *A_pro + fn_logden_trnc_Normal_B(th_cur, *th_pro, v, 0.0);
        } //if (trnc_sign == (1)) {

        if (trnc_sign == 0)  // no truncation -- Random Walk
        {
            GetRNGstate();
            *th_pro = th_cur + rnorm(0.0, 1.0)*sqrt(v);
            PutRNGstate();
        } //if (trnc_sign == (0)) {
        
    }
    
    /*
     ########## update beta_D1 (& beta_PD1)  decreasing in dose
     ###  Prior: Be_D1 \sim N(\Be_D1_bar, \tau2_D1)1(\Be_D1 > 0)  ==> trnc_sign = -1
     ###  Prior: Be_PD1 \sim N(\Be_PD1_bar, \tau2_PD1)1(\Be_PD1 < 0)  ==> trnc_sign = -1
     
     ###  Prior: Be_D2 \sim N(\Be_D2_bar, \tau2_D2)1(\Be_D2 < 0) ==> trnc_sign = -1
     ###  Prior: Be_PD2 \sim N(\Be_PD2_bar, \tau2_PD2)1(\Be_PD2 < 0) ==> trnc_sign = -1

     ##  NN_t: # of patients
     ##  Delta_D:  binary indicators where Y_{iD}^o is observed (observed: 1, censored: 0)
     ### Delta_D = ind_PD
     ###  where if PD is observed from symptoms and signs ==> if so, then ind_PD = 1
     
     ##  Be_D0:  NN_t-dim vector of \beta_D0 using v_{x_i}
     ##  dose: NNt-dim vector of doses
     ##  gam: NN_t*4-dim frailty matrix
     ###  KK_j = sum^{e_ij-1} exp(lam_jq)*len_int[q] + lam_j[e_ij]*res_y_j[i_n])
     
     ### ind_j=0 (Death), 2 (PD)
     */
    
    void fn_update_be_D(int NNt, double *dose, int *Delta, double *Be_cur, double *KK_sum, double *gam, double *Be_bar, double *tau2, int *trnc_sign, int ind_j, int *Accpt_cnt, double *v2_MH)
    {
        double A_cur, A_pro, u, eta_iD;
        int i_Be, i_n, s_ind_3;
        
        double *Be_pro; Be_pro = new double[3];
        
        int s_ind = NNt*ind_j;
        
        if(ind_j == 0)
        {
            s_ind_3 = 0;  // Death - Be 0, 1, 2
        }
        
        if(ind_j == 1)
        {
            s_ind_3 = 3;  // Tox - Be 3, 4, 5
        }
        
        // copy current values
        for (i_Be = 0; i_Be < 3; i_Be++) {
            Be_pro[i_Be] = Be_cur[s_ind_3 + i_Be];
        }
        
        for (i_Be = 0; i_Be < 3; i_Be++) {
            //### make a proposal + compute transition den
            // (trnc_sign=-1) <=> be < 0 ===> truncated from above
            // (trnc_sign = 1) <=> be > 0 ===> truncated from below
            GetRNGstate();
            Be_pro[i_Be] = Be_cur[s_ind_3 + i_Be] + rnorm(0.0, sqrt(v2_MH[s_ind_3 + i_Be]));
            PutRNGstate();
            
            // trunc_sign = -1 (for negative values), 0 (for no constraint), 1 (positive constraint)
            if((Be_pro[i_Be]*(1.0*trnc_sign[i_Be])) >= 0.0) // meet the sign constraints;
            {
                // Prior
                A_cur = 0.0 - pow(Be_cur[s_ind_3 + i_Be] - Be_bar[s_ind_3 + i_Be], 2.0)/2.0/tau2[s_ind_3 + i_Be];
                A_pro = 0.0 - pow(Be_pro[i_Be] - Be_bar[s_ind_3 + i_Be], 2.0)/2.0/tau2[s_ind_3 + i_Be];
                
                //printf("\n i_be=%d, bar=%f, var=%f", i_Be,  Be_bar[s_ind_3 + i_Be], tau2[s_ind_3 + i_Be]);
                // Like
                for (i_n = 0; i_n < NNt; i_n ++) {
                    //## evaluate eta -- current  -- 10*std_dose
                    eta_iD = Be_cur[s_ind_3 + 1]/(1.0 + exp(Be_cur[s_ind_3]*(10.0*dose[i_n] - Be_cur[s_ind_3 + 2]))) + gam[s_ind + i_n];
                    A_cur = A_cur + 1.0*Delta[s_ind + i_n]*eta_iD - exp(eta_iD)*KK_sum[s_ind + i_n];
                    
                    //## evaluate eta -- proposed -- 10*std_dose
                    eta_iD = Be_pro[1]/(1.0 + exp(Be_pro[0]*(10.0*dose[i_n] - Be_pro[2]))) + gam[s_ind + i_n];
                    A_pro = A_pro + 1.0*Delta[s_ind + i_n]*eta_iD - exp(eta_iD)*KK_sum[s_ind + i_n];
                } //## for(i_n in 1:NNt)
                
                //Let's do M-H
                GetRNGstate();
                u = runif(0.0, 1.0);
                PutRNGstate();
                
                //### Accept?
                if(log(u) < (A_pro - A_cur))
                {
                    Be_cur[s_ind_3 + i_Be] = Be_pro[i_Be];
                    Accpt_cnt[s_ind_3 + i_Be] =  Accpt_cnt[s_ind_3 + i_Be] + 1;
                }else{ // if(log(u) < (A_pro - A_cur))
                    Be_pro[i_Be] = Be_cur[s_ind_3 + i_Be];
                }//if(log(u) < (A_pro - A_cur))
            }else{
                Be_pro[i_Be] = Be_cur[s_ind_3 + i_Be];
            }//if((Be_pro[i_Be]*(1.0*trnc_sign[i_Be])) >= 0.0) // meet the sign constraints;
        }//for (i_Be = 0; i_Be < 3; i_Be++) {
        
        delete[] Be_pro; Be_pro = NULL;
    }
    
    /*
     ########## update beta_T1
     ###  Prior: Be_T1 \sim N(\Be_T1_bar, \tau2_T1)1(\Be_T1 > 0) ==> trnc_sign = 1
     
     ##  NN_t: # of patients
     ##  Delta_T:  binary indicators where Y_{iT}^o is observed (observed: 1, censored: 0)
     ##  Be_T0:  NN_t-dim vector of \beta_T0 using v_{x_i}
     ##  dose: NNt-dim vector of doses
     ##  gam: NN_t*4-dim frailty matrix
     ###  KK_j = sum^{e_ij-1} exp(lam_jq)*len_int[q] + lam_j[e_ij]*res_y_j[i_n])
     */
    
    double fn_update_be_T1(int NNt, double *dose, int *Delta, double Be_T1_cur, double *KK_sum, double *gam, double Be_T1_bar, double tau2_T1, int trnc_sign, int ind_j, int *Accpt_cnt, double *v2_MH)
    {
        double Be_T1_pro, A_cur, A_pro, u, eta_iT, tmp_cur, tmp_pro;
        int i_n;
        int s_ind_3, s_ind = NNt*ind_j;
        
        if (ind_j == 1) {
            s_ind_3 = 3; //Tox
        }
        
        if (ind_j == 2) {
            s_ind_3 = 6; //PD
        }
        
        //### make a proposal + compute transition den
        // (trnc_sign=-1) <=> be < 0 ===> truncated from above
        // (trnc_sign = 1) <=> be > 0 ===> truncated from below
        GetRNGstate();
        Be_T1_pro = Be_T1_cur + rnorm(0.0, sqrt(v2_MH[s_ind_3]));
        PutRNGstate();
        
        // trunc_sign = -1 (for negative values), 0 (for no constraint), 1 (positive constraint)
        if((Be_T1_pro*(1.0*trnc_sign)) >= 0.0) // meet the sign constraints;
        {
            // Prior
            A_cur = 0.0 - pow(Be_T1_cur - Be_T1_bar, 2.0)/2.0/tau2_T1;
            A_pro = 0.0 - pow(Be_T1_pro - Be_T1_bar, 2.0)/2.0/tau2_T1;
            
            //printf("\n Be_bar=%f, tau2=%f, A_cur=%f, A_pro=%f", Be_T1_bar, tau2_T1, A_cur, A_pro);
            
            //Like
            for (i_n = 0; i_n < NNt; i_n ++) {
                //## evaluate eta -- current
                eta_iT = Be_T1_cur*dose[i_n] + gam[s_ind + i_n];
                tmp_cur = 1.0*Delta[s_ind + i_n]*eta_iT - exp(eta_iT)*KK_sum[s_ind + i_n];
                //eta_c = eta_iT;
                
                //## evaluate eta -- proposed
                eta_iT = Be_T1_pro*dose[i_n] + gam[s_ind + i_n];
                tmp_pro = 1.0*Delta[s_ind + i_n]*eta_iT - exp(eta_iT)*KK_sum[s_ind + i_n];
                
                A_pro = A_pro + tmp_pro - tmp_cur;
                //printf("\n i_n=%d, eta_c=%f, eta_p=%f, tmp_c=%f, tmp_p=%f, KK=%f", i_n, eta_c, eta_iT, tmp_cur, tmp_pro, KK_sum[s_ind + i_n]);
            } //## for(i_n in 1:NNt)
            
            //Let's do M-H
            GetRNGstate();
            u = runif(0.0, 1.0);
            PutRNGstate();
            
            //printf("\n A_cur=%f, A_pro=%f", A_cur, A_pro);
            
            //### Accept?
            if(log(u) < (A_pro - A_cur))
            {
                Be_T1_cur = Be_T1_pro;
                Accpt_cnt[s_ind_3] =  Accpt_cnt[s_ind_3] + 1;
            }
        }//if((Be_T1_pro*(1.0*trnc_sign)) >= 0.0)
        return Be_T1_cur;
    }

    /*
     ########## update beta_D1 (& beta_PD1) -- decreasing in dose
     ###  Prior: Be_D1 \sim N(\Be_D1_bar, \tau2_D1)1(\Be_D1 < 0)  ==> trnc_sign = -1
     ###  Prior: Be_PD1 \sim N(\Be_PD1_bar, \tau2_PD1)1(\Be_PD1 > 0)  ==> trnc_sign = -1
     
     ###  Prior: Be_D2 \sim N(\Be_D2_bar, \tau2_D2)1(\Be_D2 < 0) ==> trnc_sign = -1
     ###  Prior: Be_PD2 \sim N(\Be_PD2_bar, \tau2_PD2)1(\Be_PD2 < 0) ==> trnc_sign = -1

     
     ##  NN_t: # of patients
     ##  Delta_D:  binary indicators where Y_{iD}^o is observed (observed: 1, censored: 0)
     ### Delta_D = ind_PD
     ###  where if PD is observed from symptoms and signs ==> if so, then ind_PD = 1
     
     ##  dose: NNt-dim vector of doses
     ##  gam: NN_t*4-dim frailty matrix
     ###  KK_j = sum^{e_ij-1} exp(lam_jq)*len_int[q] + lam_j[e_ij]*res_y_j[i_n])
     
     ### ind_j=0 (Death), 2 (PD)
     */
    void fn_update_be_D_ALL(int NNt, double *dose, int *Delta, double *Be_cur, double *KK_sum, double *gam, double *Be_bar, double *tau2, int *trnc_sign, int ind_j)
    {
        double A_cur, A_pro, u, eta_iD;
        int ind_pro, i_Be, i_n, s_ind_3;
        
        double *Be_pro; Be_pro = new double[3];
        
        int s_ind = NNt*ind_j;
        
        if(ind_j == 0)
        {
            s_ind_3 = 0;  // Death - Be 0, 1, 2
        }
        
        if(ind_j == 1)
        {
            s_ind_3 = 3;  // Tox - Be 3, 4, 5
        }
        
        ind_pro = 1;
        
        //### make a proposal + compute transition den
        // (trnc_sign=-1) <=> be < 0 ===> truncated from above
        // (trnc_sign = 1) <=> be > 0 ===> truncated from below
        A_cur = 0.0;
        A_pro = 0.0;
        
        for (i_Be = 0; i_Be < 3; i_Be++) {
            GetRNGstate();
            Be_pro[i_Be] = Be_cur[s_ind_3 + i_Be] + rnorm(0.0, 0.01);
            PutRNGstate();
            
            // trunc_sign = -1 (for negative values), 0 (for no constraint), 1 (positive constraint)
            if((Be_pro[i_Be]*(1.0*trnc_sign[i_Be])) >= 0.0) // meet the sign constraints;
            {
                // Prior
                A_cur = A_cur - pow(Be_cur[s_ind_3 + i_Be] - Be_bar[s_ind_3 + i_Be], 2.0)/2.0/tau2[s_ind_3 + i_Be];
                A_pro = A_pro - pow(Be_pro[i_Be] - Be_bar[s_ind_3 + i_Be], 2.0)/2.0/tau2[s_ind_3 + i_Be];
            }else{
                ind_pro = 0;
            }
        }//for (i_Be = 0; i_Be < 3; i_Be++) {
        
        if(ind_pro == 1)
        {
            // Like
            for (i_n = 0; i_n < NNt; i_n ++) {
                //## evaluate eta -- current  -- 10*std_dose
                eta_iD = Be_cur[s_ind_3 + 1]/(1.0 + exp(Be_cur[s_ind_3]*(10.0*dose[i_n] - Be_cur[s_ind_3 + 2]))) + gam[s_ind + i_n];
                A_cur = A_cur + 1.0*Delta[s_ind + i_n]*eta_iD - exp(eta_iD)*KK_sum[s_ind + i_n];
                
                //## evaluate eta -- proposed -- 10*std_dose
                eta_iD = Be_pro[1]/(1.0 + exp(Be_pro[0]*(10.0*dose[i_n] - Be_pro[2]))) + gam[s_ind + i_n];
                A_pro = A_pro + 1.0*Delta[s_ind + i_n]*eta_iD - exp(eta_iD)*KK_sum[s_ind + i_n];
            } //## for(i_n in 1:NNt)
            
            //Let's do M-H
            GetRNGstate();
            u = runif(0.0, 1.0);
            PutRNGstate();
            
            //### Accept?
            if(log(u) < (A_pro - A_cur))
            {
                for (i_Be = 0; i_Be < 3; i_Be++) {
                    Be_cur[s_ind_3 + i_Be] = Be_pro[i_Be];
                } // for (i_Be = 0; i_Be < 3; i_Be++) {
            }//if(log(u) < (A_pro - A_cur))
        }//if(ind_pro == 1)
        
        delete[] Be_pro; Be_pro = NULL;
    }
    
    
    
    //###############################################################################################################
    //+++++++++ Update Be_D1, Be_D2, Be_T1, Be_PD1 and Be_PD2
    //###############################################################################################################
    void fn_update_Be(int NNt, double *dose, double *gam, int *Delta, double *KK_sum,
                      double *Be, double *Be_bar, double *tau2, int *Accpt_cnt, double *v2_MH)
    {
        int *trnc_sign;
        trnc_sign = new int[3];
        
        trnc_sign[0] = 0;  // no trunction
        trnc_sign[1] = -1;  // negative value
        trnc_sign[2] = 0;   // no trunction
        
        // Death - // no truncation for Be_D1, Be_D2 < 0, no truncation for Be3 ==> no constraint on the direction of dose effect on death
        fn_update_be_D(NNt, dose, Delta, Be, KK_sum, gam, Be_bar, tau2, trnc_sign, 0, Accpt_cnt, v2_MH);
        
        // Tox -- update // Be_T1 >0, Be_T2 < 0, no truncation for Be_T3 ==> increasing
        trnc_sign[0] = 1;  // positive value
        fn_update_be_D(NNt, dose, Delta, Be, KK_sum, gam, Be_bar, tau2, trnc_sign, 1, Accpt_cnt, v2_MH); // j=1
        
        // PD -- Be_PD1 can be any
        Be[6] = fn_update_be_T1(NNt, dose, Delta, Be[6], KK_sum, gam, Be_bar[6], tau2[6], 0, 2, Accpt_cnt, v2_MH); // Be_PD1 no trunction, j=2
        
        delete[] trnc_sign; trnc_sign = NULL;
    }
    

    
    //###############################################################################################################
    //+++++++++ Update Be_D1, Be_D2, Be_T1, Be_PD1 and Be_PD2
    //###############################################################################################################
    void fn_update_Be_ALL(int NNt, double *dose, double *gam, int *Delta, double *KK_sum,
                          double *Be, double *Be_bar, double *tau2, int *Accpt_cnt, double *v2_MH)
    {
        int *trnc_sign;
        trnc_sign = new int[3];
        
        trnc_sign[0] = 0; // no trunction
        trnc_sign[1] = -1;  // negative value
        trnc_sign[2] = 0;  // no trunction
        
        // Death - // no truncation for Be_D1, Be_D2 < 0, no truncation for Be3 ==> no constraint on the direction of dose effect on death
        fn_update_be_D_ALL(NNt, dose, Delta, Be, KK_sum, gam, Be_bar, tau2, trnc_sign, 0);  // Be_D1 can be any & Be_D2 < 0, Be_D3 can be any
        
        // Tox -- update // Be_T1 >0, Be_T2 < 0, no truncation for Be_T3 ==> increasing
        trnc_sign[0] = 1;  // positive value
        fn_update_be_D_ALL(NNt, dose, Delta, Be, KK_sum, gam, Be_bar, tau2, trnc_sign, 1);
        
        // PD -- Be_PD1 can be any
        Be[6] = fn_update_be_T1(NNt, dose, Delta, Be[6], KK_sum, gam, Be_bar[6], tau2[6], 0, 2, Accpt_cnt, v2_MH); // Be_PD1 no trunction, j=2

        delete[] trnc_sign; trnc_sign = NULL;
    }
    
    /*
    void fn_test(int *zz, double *mm, double *u_cutoff, double *vv, double *log_pi)
    {
        int z = *zz;
        double m = *mm;
        double v= *vv;
        
        int JJ_1 = 4;
        
        double tmp0, tmp1;
        
        // Z=0: ppi0 = P(X < cutoff[0]) where X ~N(m, sig2_pi)
        //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
        if (z == 0) {
            *log_pi = pnorm(u_cutoff[z], m, sqrt(v), 1, 1);
        }
        
        if ((z > 0)&(z < (JJ_1 - 1))) { // z= 1, 2
            tmp0 = pnorm(u_cutoff[z-1], m, sqrt(v), 1, 0);  //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
            tmp1 = pnorm(u_cutoff[z], m, sqrt(v), 1, 0);    //# pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
            
            printf("\n tmp1=%f, tmp0=%f", tmp1, tmp0);
            
            if ((tmp1 - tmp0) > 0.0000001) {
                *log_pi = log(tmp1 - tmp0);
                
            }else{
                *log_pi = -100000;
            }
        }
        
        if (z == (JJ_1 - 1)) { //z=3
            *log_pi = pnorm(u_cutoff[z], m, sqrt(v), 0, 1);
        }
        
        printf("\n log=%f", log(0.000000001));
    }
     */

    // compute log-Pi-sum
    double fn_compute_log_PPi_sum(int NNt, int JJ_1, double *u_cutoff, double *dose, int *Z_obs, double *gam, double sig2_pi,
                                  double xi_l, double phi, double *Alpha, int i_l)
    {
        int i_n, z_1, z_2;
        int s_ind = 3*NNt;
        double u, log_Pi_sum = 0.0;
        
        if (i_l==0) {
            
            // for image 1
            for (i_n = 0; i_n < NNt; i_n ++) {
                //### if imaging at t*_1 is done
                z_1 = Z_obs[i_n];
                
                if(z_1 >= 0)
                {
                    //###  mean for psi_{i1}
                    u = xi_l + phi*dose[i_n] + gam[s_ind + i_n];
                    log_Pi_sum = log_Pi_sum + fn_compute_log_PPi(z_1, u, u_cutoff, sig2_pi, JJ_1);
                }
            }//for (i_n = 0; i_n < NNt; i_n ++) {
        }else{
            // for image 2
            for (i_n = 0; i_n < NNt; i_n ++) {
                z_2 = Z_obs[NNt + i_n];
                
                if(z_2 >= 0)
                {
                    z_1 = Z_obs[i_n];
                    
                    u = xi_l + phi*dose[i_n] + Alpha[z_1] + gam[s_ind + i_n];
                    log_Pi_sum = log_Pi_sum + fn_compute_log_PPi(z_2, u, u_cutoff, sig2_pi, JJ_1);
                } //## if(z_2 >=0)
                
            } //### for(i_n in 1:NNt)
        }//if (i_l==0) {
        
        return log_Pi_sum;
    }

    // update xi_1, xi_2, phi, alpha_2, alpha_3 all together using M-H
    // Accpt_cnt_Z and v2_MH_Z (phi, xi1, xi2, alpha3, alpha_4)
    void fn_update_phi_MH(int NNt, int JJ_1, double *u_cutoff, double *dose, int *Z_obs, double *gam, double sig2_pi,
                          double *xi, double *Alpha,
                          double *phi, double phi_bar, double tau2_phi, double *log_Pi_sum_cur, int *Accpt_cnt_Z, double *v2_MH_Z)
    {
        int i_l;
        double u, phi_pro, phi_cur = *phi;
        double *log_Pi_sum_pro; log_Pi_sum_pro = new double[2];
        
        double A_cur = 0.0;
        double A_pro = 0.0;
        
        // propose phi - dose effect  & evaluate prior-- phi no trunction
        GetRNGstate();
        phi_pro = phi_cur + rnorm(0.0, sqrt(v2_MH_Z[0]));
        PutRNGstate();
        
        // Prior + Transition density
        A_cur = A_cur - pow(phi_cur - phi_bar, 2.0)/2.0/tau2_phi;      // Prior for phi_cur
        A_pro = A_pro - pow(phi_pro - phi_bar, 2.0)/2.0/tau2_phi;      // Prior for phi_pro
        
        // Likelihood-- phi affects likelihood for both image 1 and image 2
        for (i_l=0; i_l < 2; i_l++) {
            A_cur = A_cur + log_Pi_sum_cur[i_l];
            
            log_Pi_sum_pro[i_l] = fn_compute_log_PPi_sum(NNt, JJ_1, u_cutoff, dose, Z_obs, gam, sig2_pi, xi[i_l], phi_pro, Alpha, i_l);
            A_pro = A_pro + log_Pi_sum_pro[i_l];
        }//for (i_l=0; i_l < 2; i_l++) {
        
        //Let's do M-H
        GetRNGstate();
        u = runif(0.0, 1.0);
        PutRNGstate();
        
        //### Accept?
        if(log(u) < (A_pro - A_cur))
        {
            //printf("\n accpt");
            *phi = phi_pro;
            
            for (i_l = 0; i_l < 2; i_l++) {
                log_Pi_sum_cur[i_l] = log_Pi_sum_pro[i_l];
            }//for (i_l = 0; i_l < 2; i_l++) {
            
            Accpt_cnt_Z[0] = Accpt_cnt_Z[0]  + 1; // phi, xi1, xi2, alpha
        }//if(log(u) < (A_pro - A_cur))
        
        delete[] log_Pi_sum_pro; log_Pi_sum_pro = NULL;
    }

    // update xi_1, xi_2, alpha_2, alpha_3 all together using M-H (NO PHI)
    // Accpt_cnt_Z and v2_MH_Z (phi, xi1, xi2, alpha3, alpha_4)
    void fn_update_xi_MH(int NNt, int JJ_1, double *u_cutoff, double *dose, int *Z_obs, double *gam, double sig2_pi,
                         double *xi_cur, double *xi_bar, double *tau2_xi,
                         double phi,
                         double *Alpha, double *log_Pi_sum_cur, int *Accpt_cnt_Z, double *v2_MH_Z)
    {
        int i_l;
        double u, log_Pi_sum_pro, xi_pro;
        
        double A_cur, A_pro;
        
        // propose xi_1 and xi_2 -- imaging 1 and imaing 2 & evaluate prior
        for (i_l = 0; i_l < 2; i_l++) {
            
            A_cur = 0.0;
            A_pro = 0.0;
            
            GetRNGstate();
            xi_pro = xi_cur[i_l] + rnorm(0.0, sqrt(v2_MH_Z[1 + i_l]));
            PutRNGstate();
            
            // Prior
            A_cur = A_cur - pow((xi_cur[i_l] - xi_bar[i_l]), 2.0)/2.0/tau2_xi[i_l];
            A_pro = A_pro - pow((xi_pro - xi_bar[i_l]), 2.0)/2.0/tau2_xi[i_l];
            
            // Likelihood
            A_cur = A_cur + log_Pi_sum_cur[i_l];
            
            log_Pi_sum_pro = fn_compute_log_PPi_sum(NNt, JJ_1, u_cutoff, dose, Z_obs, gam, sig2_pi, xi_pro, phi, Alpha, i_l);
            A_pro = A_pro + log_Pi_sum_pro;
            
            //Let's do M-H
            GetRNGstate();
            u = runif(0.0, 1.0);
            PutRNGstate();
            
            //### Accept?
            if(log(u) < (A_pro - A_cur))
            {
                xi_cur[i_l] = xi_pro;
                log_Pi_sum_cur[i_l] = log_Pi_sum_pro;
                
                Accpt_cnt_Z[1 + i_l] = Accpt_cnt_Z[1 + i_l] + 1;
            }//if(log(u) < (A_pro - A_cur))
        }//for (i_l = 0; i_l < 2; i_l++) {
    }
    

    // update alpha_2 & alpha_3 using M-H (NO PHI)
    // Accpt_cnt_Z and v2_MH_Z (phi, xi1, xi2, alpha3, alpha_4)
    void fn_update_alpha_MH(int NNt, int JJ_1, double *u_cutoff, double *dose, int *Z_obs, double *gam, double sig2_pi,
                            double *xi, double phi,
                            double *Alpha_cur, double *Alpha_bar, double *v2_alpha, double *log_Pi_sum_cur, int *Accpt_cnt_Z, double *v2_MH_Z)
    {
        int z_1, ind_pro;
        double u, log_Pi_sum_pro;
        double alpha_z_pro, alpha_z_cur, A_cur, A_pro;
        
        //## effect of PR and CR (z_1= 2, 3)  --- where z_1 can be either of 0, 1, 2, 3.
        //a_0=0, a_1=0, a1 < a2 < a3 with J_1=4
        for (z_1 = 2; z_1 < JJ_1; z_1 ++) { // alpha_0 = alpha_1 = 0
            
            alpha_z_cur = Alpha_cur[z_1]; // save the current alpha
            
            // Propose a value
            GetRNGstate();
            alpha_z_pro = alpha_z_cur + rnorm(0.0, sqrt(v2_MH_Z[z_1 + 1]));
            PutRNGstate();
            
            ind_pro = 0;
            if(z_1 == (JJ_1 - 1)) // last category?
            {
                if(Alpha_cur[z_1-1] < alpha_z_pro)
                {
                    ind_pro = 1;
                }
            }else{
                if((Alpha_cur[z_1-1] < alpha_z_pro)&&(alpha_z_pro < Alpha_cur[z_1+1]))
                {
                    ind_pro = 1;
                }
            }//if(z_1 == (JJ_1 - 1)) // last category?

            if(ind_pro == 1)  // proposal meets the constraints -- a_0=0, a_1=0, a1 < a2 < a3
            {
                A_cur = 0.0;
                A_pro = 0.0;
                
                // Prior -- have the same constraint so the normalizing cosntant is cacelled
                A_cur = A_cur - pow((alpha_z_cur - Alpha_bar[z_1]), 2.0)/2.0/v2_alpha[z_1];
                A_pro = A_cur - pow((alpha_z_pro - Alpha_bar[z_1]), 2.0)/2.0/v2_alpha[z_1];
                
                // Likelihood
                A_cur = A_cur + log_Pi_sum_cur[1];  // since alpha affects image2 likelihood
                
                Alpha_cur[z_1] = alpha_z_pro;  // have the proposal
                log_Pi_sum_pro = fn_compute_log_PPi_sum(NNt, JJ_1, u_cutoff, dose, Z_obs, gam, sig2_pi, xi[1], phi, Alpha_cur, 1);
                A_pro = A_pro + log_Pi_sum_pro;
                
                //Let's do M-H
                GetRNGstate();
                u = runif(0.0, 1.0);
                PutRNGstate();
                
                //### Accept?
                if(log(u) < (A_pro - A_cur))
                {
                    Alpha_cur[z_1] = alpha_z_pro; // alpha_2, alpha_3
                    log_Pi_sum_cur[1] = log_Pi_sum_pro;
                    
                    Accpt_cnt_Z[z_1 + 1] = Accpt_cnt_Z[z_1 + 1]  + 1;
                }else{
                    Alpha_cur[z_1] = alpha_z_cur; // alpha_2, alpha_3
                }//if(log(u) < (A_pro - A_cur))
            }//if((Alpha_cur[z_1-1] < alpha_z_pro)&&(alpha_z_pro < Alpha_cur[z_1+1]))
        }//for (z_1 = 2; z_1 < JJ_1; z_1 ++) { // alpha_0 = alpha_1=0
    }
 
    /* ### update phi, gam, mu, alpha --------------------------
     ##  NN_t: # of patients
     ### psi_i1 \sim N(xi_1 + \phi*d_i + gam_{i, PD2}, \sig2_\pi)  --- No MU & No Alpha !!!!!!!!!
     ### psi_i2 \sim N(xi_2 + \phi*d_i + alpha_z1i + gam_{i, PD2}, \sig2_\pi)
     
     ## phi: scalar -- dose effect on imaging outcomes
     ## alpha: JJ_1-dim vector, alpha_0=alpha_1=0 with JJ_1=4 (PD, SD, PR, CR)
     ## xi: xi1 & xi2 -- imaging time effects
     
     ##  dose: NNt-dim vector of doses
     ##  gam: NN_t*4-dim frailty matrix
     */
    

    void fn_update_Z_para(int NNt, int JJ_1, double *dose, int *Z_obs, double *gam,
                          double *xi, double *xi_bar, double *tau2_xi,
                          double *phi, double phi_bar, double tau2_phi,
                          double *Alpha, double *Alpha_bar, double *v2_alpha,
                          double sig2_pi, double *u_cutoff, int *Accpt_cnt_Z, double *v2_MH_Z)
    {
        double *log_Pi_sum; log_Pi_sum = new double[2];
        int i_l;
        
        for (i_l=0; i_l < 2; i_l++) {
            log_Pi_sum[i_l] = fn_compute_log_PPi_sum(NNt, JJ_1, u_cutoff, dose, Z_obs, gam, sig2_pi, xi[i_l], *phi, Alpha, i_l);
        }

        // update phi using M-H
        fn_update_phi_MH(NNt, JJ_1, u_cutoff, dose, Z_obs, gam, sig2_pi, xi, Alpha, phi, phi_bar, tau2_phi, log_Pi_sum, Accpt_cnt_Z, v2_MH_Z);
        
        // update xi_1, and xi_2 using M-H
        fn_update_xi_MH(NNt, JJ_1, u_cutoff, dose, Z_obs, gam, sig2_pi, xi, xi_bar, tau2_xi, *phi, Alpha, log_Pi_sum, Accpt_cnt_Z, v2_MH_Z);
        
        // update alpha_2, alpha_3 using M-H
        fn_update_alpha_MH(NNt, JJ_1, u_cutoff, dose, Z_obs, gam, sig2_pi, xi, *phi, Alpha, Alpha_bar, v2_alpha, log_Pi_sum, Accpt_cnt_Z, v2_MH_Z);
        
        delete[] log_Pi_sum; log_Pi_sum = NULL;
    }
    
    
    // update xi_1, xi_2, phi, alpha_2, alpha_3 all together using M-H
    void fn_update_Z_para_ALL(int NNt, int JJ_1, double *dose, int *Z_obs, double *gam, double *xi_cur, double *xi_bar, double *tau2_xi,
                              double *phi, double phi_bar, double tau2_phi, double *Alpha_cur, double *Alpha_bar, double *v2_alpha,
                              double sig2_pi, double *u_cutoff)
    
    {
        int i_l, z_1, ind_pro;
        double u;
        
        double *xi_pro; xi_pro = new double[2];
        double *Alpha_pro; Alpha_pro = new double[JJ_1];
        double phi_pro, phi_cur = *phi;
        
        double A_cur = 0.0;
        double A_pro = 0.0;
        
        // propose xi_1 and xi_2 -- imaging 1 and imaing 2 & evaluate prior
        for (i_l = 0; i_l < 2; i_l++) {
            GetRNGstate();
            xi_pro[i_l] = xi_cur[i_l] + rnorm(0.0, 0.01);
            PutRNGstate();
            
            // Prior
            A_cur = A_cur - pow((xi_cur[i_l] - xi_bar[i_l]), 2.0)/2.0/tau2_xi[i_l];
            A_pro = A_pro - pow((xi_pro[i_l] - xi_bar[i_l]), 2.0)/2.0/tau2_xi[i_l];
        }
        
        // propose phi - dose effect  & evaluate prior-- phi no trunction
        GetRNGstate();
        phi_pro = phi_cur + rnorm(0.0, 0.01);
        PutRNGstate();
        
        // Prior
        A_cur = A_cur - pow(phi_cur - phi_bar, 2.0)/2.0/tau2_phi;      // Prior for phi_cur
        A_pro = A_pro - pow(phi_pro - phi_bar, 2.0)/2.0/tau2_phi;      // Prior for phi_pro

        ind_pro = 1;
        if(ind_pro == 1) // proposal of alpha + prior of alpha
        {
            //## effect of PR and CR (z_1= 2, 3)  --- where z_1 can be either of 0, 1, 2, 3.
            //a_0=0, a_1=0, a1 < a2 < a3
            Alpha_pro[0] = 0.0;
            Alpha_pro[1] = 0.0;
            
            for (z_1 = 2; z_1 < JJ_1; z_1 ++)
            {
                // Propose a value
                GetRNGstate();
                Alpha_pro[z_1] = Alpha_cur[z_1] + rnorm(0.0, 0.01);
                PutRNGstate();
                
                // Prior + Transition density
                A_cur = A_cur + fn_logden_trnc_Normal_B(Alpha_cur[z_1], Alpha_bar[z_1], v2_alpha[z_1], Alpha_cur[z_1-1]);  // Prior for alpha_cur
                A_pro = A_pro + fn_logden_trnc_Normal_B(Alpha_pro[z_1], Alpha_bar[z_1], v2_alpha[z_1], Alpha_pro[z_1-1]);  // Prior for alpha_pro
                
                if(Alpha_pro[z_1-1] > Alpha_pro[z_1]) // check ordering constraints
                {
                    ind_pro = 0;
                }
            }//for (z_1 = 2; z_1 < JJ_1; z_1 ++)
        }//if(ind_pro = 1) // proposal of alpha + prior of alpha
                

        if(ind_pro == 1)// if all proposals meet the constraints
        {
            // Likelihood
            for (i_l=0; i_l < 2; i_l++) {
                A_cur = A_cur + fn_compute_log_PPi_sum(NNt, JJ_1, u_cutoff, dose, Z_obs, gam, sig2_pi, xi_cur[i_l], phi_cur, Alpha_cur, i_l);
                A_pro = A_pro + fn_compute_log_PPi_sum(NNt, JJ_1, u_cutoff, dose, Z_obs, gam, sig2_pi, xi_pro[i_l], phi_pro, Alpha_pro, i_l);
            }//for (i_l=0; i_l < 2; i_l++) {
            
            //Let's do M-H
            GetRNGstate();
            u = runif(0.0, 1.0);
            PutRNGstate();
            
            //### Accept?
            if(log(u) < (A_pro - A_cur))
            {
                *phi = phi_pro;
                
                for (i_l = 0; i_l < 2; i_l++) {
                    xi_cur[i_l] = xi_pro[i_l];
                    Alpha_cur[i_l + 2] = Alpha_pro[i_l + 2]; // alpha_2, alpha_3
                } // for (i_l = 0; i_l < 2; i_l++) {
            }//if(log(u) < (A_pro - A_cur))
        }//if(ind_pro = 1)// if all proposals meet the constraints

        delete[] xi_pro; xi_pro = NULL;
        delete[] Alpha_pro; Alpha_pro = NULL;
    }
    
    
    void fn_adjust_v2_MH(int *Accpt_cnt, double *v2_MH, int tmp)
    {
        double Max_M = log(50.0);
        double Min_M = -1.0*Max_M;
        double tmp2;
        
        int i; //, tmp = (*i_iter/50); //quotient
        int Be_cnt = 6;  // # of betas
    
        double stp_sz = fn_min(0.20, 1.0/sqrt(tmp));
        stp_sz = fn_min(stp_sz, Max_M);
        
        Accpt_cnt[6] = Accpt_cnt[6]/2;  // since we update beta_PD twice
        
        for (i=0; i < Be_cnt; i++) {
            if (((1.0*Accpt_cnt[i])/50.0) < 0.44) {
                tmp2 = log(v2_MH[i]) - stp_sz; // decrase
            }else{
                tmp2 = log(v2_MH[i]) + stp_sz; //increase
            }//if (((1.0*Accpt_cnt[i])/50.0) < 0.44) {
            
            if (tmp2 < Min_M) {
                tmp2 = Min_M;
            }//if (tmp2 < Min_M) {
            
            if (tmp2 > Max_M) {
                tmp2 = Max_M;
            }//if (tmp2 > Max_M) {
            
            v2_MH[i] = exp(tmp2);
            Accpt_cnt[i] = 0;
        }//for (i=0; i < 7; i++) {
    }
    
    void fn_adjust_v2_MH_Z(int *Accpt_cnt, double *v2_MH, int tmp)
    {
        double Max_M = log(10.0);
        double Min_M = log(0.001);
        double tmp2;
        
        int i; //, tmp = (*i_iter/50); //quotient
        
        double stp_sz = fn_min(0.30, 1.0/sqrt(tmp));
        stp_sz = fn_min(stp_sz, Max_M);
        
        for (i=0; i < 5; i++) {
            if (((1.0*Accpt_cnt[i])/50.0) < 0.44) {
                tmp2 = log(v2_MH[i]) - stp_sz; // decrase
            }else{
                tmp2 = log(v2_MH[i]) + stp_sz; //increase
            }//if (((1.0*Accpt_cnt[i])/50.0) < 0.44) {
            
            if (tmp2 < Min_M) {
                tmp2 = Min_M;
            }//if (tmp2 < Min_M) {
            
            if (tmp2 > Max_M) {
                tmp2 = Max_M;
            }//if (tmp2 > Max_M) {
            
            v2_MH[i] = exp(tmp2);
            Accpt_cnt[i] = 0;
        }//for (i=0; i < 7; i++) {
    }
    
    
    void fn_adjust_v2_MH_lam(int *Accpt_cnt, double *v2_MH, int Q_max, int *QQ, int JJ, int tmp)
    {
        double Max_M = log(10.0);
        double Min_M = log(0.001);
        double tmp2;
        int i_j, i_q, s_ind_1;

        double stp_sz = fn_min(0.30, 1.0/sqrt(tmp));
        stp_sz = fn_min(stp_sz, Max_M);
        
        for (i_j=0; i_j < JJ; i_j++) {
            s_ind_1 = Q_max*i_j;    // starting indicator  -- for lambda
            
            //## one at a time, lam_{jq}
            for (i_q = 0; i_q < QQ[i_j]; i_q++) {
                
                if (((1.0*Accpt_cnt[s_ind_1 + i_q])/50.0) < 0.44) {
                    tmp2 = log(v2_MH[s_ind_1 + i_q]) - stp_sz; // decrase
                }else{
                    tmp2 = log(v2_MH[s_ind_1 + i_q]) + stp_sz; //increase
                }//if (((1.0*Accpt_cnt[i])/50.0) < 0.44) {
                
                if (tmp2 < Min_M) {
                    tmp2 = Min_M;
                }//if (tmp2 < Min_M) {
                
                if (tmp2 > Max_M) {
                    tmp2 = Max_M;
                }//if (tmp2 > Max_M) {
                
                v2_MH[s_ind_1 + i_q] = exp(tmp2);
                Accpt_cnt[s_ind_1 + i_q] = 0;
            } //## for(i_q in 1:QQ)
        }
    }

    void fn_Discrete_MCMC_Burn(double *dose, double *YY, int *Z_obs,
                               int Q_max, int *QQ, int *Delta, int *Ind_y,
                               double *SS, double *Len_int, double *res_y, // s -- hazard cutpoints
                               double *lam, double *sig2, double *lam0, double *sig2_0, double *KK_sum, int *Accpt_cnt_lam, double *v2_MH_lam, // Lambda for all outcomes
                               double *Be, double *Be_bar, double *tau2, // death - Be1 and Be2 // Tox - Be1 // PD - Be1 and Be2
                               int *Accpt_cnt, double *v2_MH,
                               // Parameters for Z
                               double *xi, double *xi_bar, double *tau2_xi, // 2-dim vector for t*_1, t*_2
                               double *phi, double phi_bar, double tau2_phi, // dose effect para for Z
                               double *Alpha, double *Alpha_bar, double *v2_alpha, // Alpha=(alpha_0, alpha_1, alpha_2, alpha_3)
                               double sig2_pi, double *u_cutoff, int *Accpt_cnt_Z, double *v2_MH_Z,
                               // Gamma - Frailties
                               double *gam, int nu, double *Omega_0, double *Inv_Omega, // gam_i: (JJ + 1)-dim vector
                               int JJ, int JJ_1, int n_t, int N_iter) // JJ=3, JJ_1=4
    {
        int i_iter;
        //printf("\n v2-MH-Z %f, %f, %f, %f, %f", v2_MH_Z[0], v2_MH_Z[1], v2_MH_Z[2], v2_MH_Z[3], v2_MH_Z[4]);

        
        //for (i_iter=0; i_iter < 1; i_iter++) {
        for (i_iter=0; i_iter < N_iter; i_iter++) {
            //printf("\n\n burn iter=%d", i_iter);
            
            // Update lambda for all j=D, T, PD and update KK_sum_j accordingly
            // Update SS (baseline hazard cutpoints) and update Len_int, Ind_y, & res_y accordingly
            fn_update_lam_SS(n_t, dose, YY, Be, gam, Q_max, QQ, Delta, lam, sig2, lam0, sig2_0, KK_sum, SS, Len_int, Ind_y, res_y, Accpt_cnt_lam, v2_MH_lam);

            // Update Be_D1, Be_D2, Be_T1, Be_PD1 and Be_PD2
            fn_update_Be(n_t, dose, gam, Delta, KK_sum, Be, Be_bar, tau2, Accpt_cnt, v2_MH);
            
            //update random effects -- update gam_{i} as a vector
            fn_update_gam(n_t, JJ, JJ_1, u_cutoff, dose, gam, Inv_Omega, Delta, Z_obs, KK_sum, Be, *phi, xi, Alpha, sig2_pi, 0);
            
            // Update xi, phi (dose effect), Alpha, Psi (latent variables)
            fn_update_Z_para(n_t, JJ_1, dose, Z_obs, gam, xi, xi_bar, tau2_xi, phi, phi_bar, tau2_phi, Alpha, Alpha_bar, v2_alpha, sig2_pi, u_cutoff, Accpt_cnt_Z, v2_MH_Z);
            
            // Update Inv_Omega  -- Inverse of Covariance Matrix of gam_i -- (J+1)*(J+1)
            fn_update_Inv_Omega(gam, nu, Omega_0, n_t, (JJ + 1), Inv_Omega);
            
            /*
            // Update lambda for all j=D, T, PD and update KK_sum_j accordingly
            // Update SS (baseline hazard cutpoints) and update Len_int, Ind_y, & res_y accordingly
            fn_update_lam_SS_1(n_t, dose, YY, Be, gam, Q_max, QQ, Delta, lam, sig2, lam0, sig2_0, KK_sum, SS, Len_int, Ind_y, res_y);
            
            // Update Be_D1, Be_D2, Be_T1, Be_PD1 and Be_PD2
            fn_update_Be_ALL(n_t, dose, gam, Delta, KK_sum, Be, Be_bar, tau2, Accpt_cnt, v2_MH);
            
            //update random effects -- update gam_{ij} one at a time
            fn_update_gam(n_t, JJ, JJ_1, u_cutoff, dose, gam, Inv_Omega, Delta, Z_obs, KK_sum, Be, *phi, xi, Alpha, sig2_pi, 0);
            
            // Update xi, phi (dose effect), Alpha, Psi (latent variables)
            fn_update_Z_para_ALL(n_t, JJ_1, dose, Z_obs, gam, xi, xi_bar, tau2_xi, phi, phi_bar, tau2_phi, Alpha, Alpha_bar, v2_alpha, sig2_pi, u_cutoff);
            
            // Update Inv_Omega  -- Inverse of Covariance Matrix of gam_i -- (J+1)*(J+1)
            fn_update_Inv_Omega(gam, nu, Omega_0, n_t, (JJ + 1), Inv_Omega);
            */
            
            if ((i_iter % 50) == 0) {
                fn_adjust_v2_MH(Accpt_cnt, v2_MH, (i_iter/50));
                fn_adjust_v2_MH_Z(Accpt_cnt_Z, v2_MH_Z, (i_iter/50));
                
                //printf("\n burn iter=%d", i_iter);
                //printf("\n v2-MH-Z %f, %f, %f, %f, %f", v2_MH_Z[0], v2_MH_Z[1], v2_MH_Z[2], v2_MH_Z[3], v2_MH_Z[4]);
            }
        }
        
    } // void fn_Discrete_MCMC_Burn(

    
    
    // sampling from a discrete distribution; cum_prob_vec = *normalized* *cumulative* prob vector and N_c: # of categories
    // ind_new  = fn_sample_cat(2, prob_vec);
    int fn_sample_cat(int N_c, double *cum_prob_vec, double start_prob)
    {
        int i_c;
        
        // Sample the cluster
        GetRNGstate();
        double u = runif(0.0, 1.0);
        PutRNGstate();
        
        u = u + start_prob;
        
        if(u > 1.0)
        {
            u = 1.0;
        }//if(u > 1.0)
        
        for(i_c = 0; i_c < N_c; i_c++){
            if(u <= cum_prob_vec[i_c]) break;
        }
        
        return i_c;
    }
    
    //fn_compute_H_for_Ut(QQ[i_j], SS, lam, max_QQ*i_j, (max_QQ + 1)*i_j, Tab_Hazd);

    void fn_compute_H_for_Ut(int Q_j, double *SS, double *lam, int s_ind_1, int s_ind_2, double *Tab_Hazd)
    {
        double base_j = 0.0;
        int i_q;
        
        /*
         // \sum exp(lam_{jq})*(s_jq - s_jq-1) only for follow-up
         base_j = 0.0;
         s_ind_1 = max_QQ*i_j;   // starting indicator  -- for lam
         s_ind_2 = (max_QQ + 1)*i_j; // starting indicator  -- for SS
         */
        
        // cumulative hazard for Utility computation
        for (i_q = 0; i_q < Q_j; i_q++) {
            base_j = base_j + exp(lam[s_ind_1 + i_q])*(SS[s_ind_2 + i_q + 1] - SS[s_ind_2 + i_q]);
            Tab_Hazd[s_ind_1 + i_q] = base_j;
            
            //printf("\n i_q=%d, lam=%f, SS0=%f, SS1=%f, base=%f", i_q, base_j);
        }//for (i_q = 0; i_q < Q_j; i_q++) {
    }
    
    double fn_compute_H_for_Ut_1(int Q_j, double Cens_j, double *SS, double *lam, int s_ind_1, int s_ind_2)
    {
        double base_j = 0.0;
        int i_q;
        
        /*
         // \sum exp(lam_{jq})*(s_jq - s_jq-1) only for follow-up
         base_j = 0.0;
         s_ind_1 = max_QQ*i_j;   // starting indicator  -- for lam
         s_ind_2 = (max_QQ + 1)*i_j;   // starting indicator  -- for SS
         */
        
        // cumulative hazard for Utility computation
        for (i_q = 0; i_q < Q_j; i_q++) {
            if (Cens_j <= SS[s_ind_2 + i_q + 1]) {
                break;
            }else{
                base_j = base_j + exp(lam[s_ind_1 + i_q])*(SS[s_ind_2 + i_q + 1] - SS[s_ind_2 + i_q]);
            }
            
        }//for (i_q = 0; i_q < Q_j; i_q++) {
        
        base_j = base_j + exp(lam[s_ind_1 + i_q])*(Cens_j - SS[s_ind_2 + i_q]);
        
        return base_j;
    }

    
    //compute safety prob & expected utility given \theta
    // Tab_Safety: MM-vector
    // Tab_Exp_Ut: MM-vetor
    void fn_compute_Safety_ExpU_one(double *Dose, int MM, int JJ, int JJ_PD, int *QQ, int max_QQ, double *u_cutoff, double sig2_pi, double *SS,
                                    double *Inv_Omega, double *lam, double *Be, double *Alpha, double *xi, double phi,
                                    double *Cens, double *pi_bar_S, double *Ut_tab, int *Tab_Safety_1, double *Tab_Exp_Ut_1, int n_sam)
    {
        int ii_sam, i_j, ii_j, s_ind_1, s_ind_2, i_d, ii, i_q, QQ_j;
        double tmp_D, tmp_T, tmp_PD, tmp_z, u, u1, AA, Pi_20, eta_j, prob_q;
        double S_PD_1, S_PD_2, base_PD, s_star;
        int Z1, Z2, ind_PD, ind_U_PD, ind_U_T;
        
        int n_sam_1 = 100;   //## marginalize over random effects
        
        double *sq_Omega; sq_Omega = new double[(JJ + 1)*(JJ + 1)];
        double *gam_vec; gam_vec = new double[JJ + 1];
        
        double *Tab_Safety; Tab_Safety = new double[JJ*MM];  // (JJ*MM)-dim matrix
        double *Tab_Exp_Ut; Tab_Exp_Ut = new double[MM];  // MM-dim vector
        int *Tab_Occ; Tab_Occ = new int[JJ];  // JJ-dim matrix -- occurrence indicator for each outcome
        
        // dose effects (JJ * MM) and baseline cumulative hazards
        double *Tab_dose; Tab_dose = new double[(JJ + 1)*MM];  // JJ*MM matrix
        double *Tab_dose_phi; Tab_dose_phi = new double[MM];   // JJ*MM matrix
        
        double *YY; YY = new double[JJ];  // JJ-dim vector
        double *Pi_1; Pi_1 = new double[JJ_PD];  // JJ_PD-dim vector
        double *Pi_2; Pi_2 = new double[JJ_PD];  // JJ_PD-dim vector
        double *Tab_Hazd; Tab_Hazd = new double[max_QQ*JJ];     // JJ-dim vector
        
        //printf("\n J=%d, M=%d, K=%d, dim=%d", JJ, MM, KK, JJ*MM*KK);
        
        // how many times safe among n_sam_1 -- for this sample
        for (ii=0; ii < (JJ*MM); ii++) {
            Tab_Safety[ii] = 0.0;
        }
        
        for (ii=0; ii < MM; ii++) {
            Tab_Exp_Ut[ii] = 0.0;
        }
        
        // compute dose effects (each dose) for D, T and PD
        for (i_d = 0; i_d < MM; i_d++) { //JJ*MM matrix
            Tab_dose[JJ*i_d + 0] =  Be[1]/(1.0 + exp(Be[0]*(10.0*Dose[i_d] - Be[2])));  // Death
            Tab_dose[JJ*i_d + 1] =  Be[4]/(1.0 + exp(Be[3]*(10.0*Dose[i_d] - Be[5])));  // Tox
            Tab_dose[JJ*i_d + 2] =  Be[6]*Dose[i_d];                  // conti-PD
            Tab_dose_phi[i_d] =  phi*Dose[i_d];                       // discrete-PD
        }
        
        // compute baseline hazard for D, T and PD
        // for utility computation - for all D, T and PD
        for (i_j = 0; i_j < JJ; i_j++) {
            // \sum exp(lam_{jq})*(s_jq - s_jq-1) only for follow-up
            fn_compute_H_for_Ut(QQ[i_j], SS, lam, max_QQ*i_j, (max_QQ + 1)*i_j, Tab_Hazd);
        }//for (i_j = 0; i_j < JJ; i_j++) {
        
        // Find the square root inverse of p*p matrix Inv_Omega and save it in sq_Omega
        fn_sq_inverse_mat(JJ+1, Inv_Omega, sq_Omega);
        
        for (ii_sam = 0; ii_sam < n_sam_1; ii_sam ++) { // marginalize over gamma
            
            //Simulate a gamma vector -- Frailty: generate samples from N(0, Sig=) where sq_Sigma = \sqrt(Sigma)
            mvn_rv(JJ+1, sq_Omega, gam_vec);
            
            for (i_d = 0; i_d < MM; i_d++) {
                
                //## begin: death & tox
                // i_j = 0 (D), 1 (Tox)
                for (i_j = 0; i_j < 2; i_j ++) {
                    s_ind_1 =  max_QQ*i_j;  // index for lam
                    s_ind_2 =  (max_QQ + 1)*i_j; // index for S
                    QQ_j = QQ[i_j];
                    eta_j = exp(gam_vec[i_j] + Tab_dose[JJ*i_d + i_j]); // JJ*MM matrix
                    
                    GetRNGstate();
                    u = runif(0.0, 1.0);
                    PutRNGstate();
                    
                    // cumulative hazard for Utility computation
                    for (i_q = 0; i_q < QQ_j; i_q++) {
                        prob_q = 1.0 - exp(-eta_j*Tab_Hazd[s_ind_1 + i_q]);
                        
                        if (u <= prob_q) {
                            break;
                        }
                    }//for (i_q = 0; i_q < Q_j; i_q++) {
                    
                    prob_q = 1.0 - exp(-eta_j*Tab_Hazd[s_ind_1 + QQ_j - 1]); // P(Y_j <= 84 days) where C_j for safety
                    
                    if(u <= prob_q)
                    {
                        // if Y_j <= C_j
                        GetRNGstate();
                        YY[i_j] = SS[s_ind_2 + i_q] + (SS[s_ind_2 + i_q + 1] - SS[s_ind_2 + i_q])*runif(0.0, 1.0);
                        PutRNGstate();
                    }else{
                        // if Y_j > C_j ==> put a dummy value greater than C_j
                        YY[i_j] = SS[s_ind_2 + QQ_j] + 100.0;
                    }//if(u <= prob_q)
                    
                }//for (i_j = 0; i_j < 2; i_j ++) {
                //## end: Death & Tox
                
                //## begin: PD -- Expected Uti
                i_j = 2; // PD
                s_ind_1 =  max_QQ*i_j;
                s_ind_2 =  (max_QQ + 1)*i_j;
                QQ_j = QQ[i_j];
                eta_j = exp(gam_vec[i_j] + Tab_dose[JJ*i_d + i_j]);
                
                // P(Z1) -- cumulative
                tmp_z = xi[0] + gam_vec[i_j + 1] + Tab_dose_phi[i_d]; // mean for t*_1
                for (ii_j = 0; ii_j < (JJ_PD-1); ii_j++) {
                    //pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
                    Pi_1[ii_j] = pnorm(u_cutoff[ii_j], tmp_z, sqrt(sig2_pi), 1, 0);
                }
                Pi_1[JJ_PD - 1] = 1.0;
                
                // \sum_z1=1^3 P(Z1=z1)*P(Z2!=0 |Z1=z1)
                AA = 0.0;
                for (ii_j = 1; ii_j < JJ_PD; ii_j++) {
                    tmp_z = xi[1] + gam_vec[i_j + 1] + Tab_dose_phi[i_d] + Alpha[ii_j]; // mean for t*_2
                    Pi_20 = pnorm(u_cutoff[0], tmp_z, sqrt(sig2_pi), 1, 0); // Pr(Z2=0 | Z1)
                    
                    AA = AA + (Pi_1[ii_j] - Pi_1[ii_j - 1])*(1.0 - Pi_20); // \sum p(z1)(1-p(z2=0 | z1), z1= 1, 2, 3
                }//for (ii_j = 1; ii_j < (JJ_PD-1); ii_j++) {
                
                // -- PD
                GetRNGstate();
                u = runif(0.0, 1.0);
                PutRNGstate();
                
                S_PD_2 = exp(-eta_j*Tab_Hazd[s_ind_1 + QQ_j - 1]);  // since C_PD = S_PD // P(conti Y_PD > 84)
                prob_q = 1.0 - S_PD_2*AA; // P(Y_PD <= 84)
                
                if (u > prob_q) { // P(Y_PD > 84)
                    YY[i_j] = SS[s_ind_2 + QQ_j] + 100.0;  // dummy: anything > 84
                    
                    // need to simulate Z1 and Z2
                    Z1 = fn_sample_cat(JJ_PD, Pi_1, Pi_1[0]); // Z1: efficacy outcome from image 1 & should not be PD
                    
                    for (ii_j = 0; ii_j < (JJ_PD-1); ii_j++) {
                        tmp_z = xi[1] + gam_vec[i_j + 1] + Tab_dose_phi[i_d] + Alpha[Z1]; // mean for t*_2 -- alpha:JJ_PD dim vector
                        Pi_2[ii_j] = pnorm(u_cutoff[ii_j], tmp_z, sqrt(sig2_pi), 1, 0); // Pr(Z2=ii_j | Z1)
                    }//for (ii_j = 0; ii_j < (JJ_PD-1); ii_j++) {
                    Pi_2[JJ_PD - 1] = 1.0;
                    
                    Z2 = fn_sample_cat(JJ_PD, Pi_2, Pi_2[0]); // Z2: efficacy outcome from image 2 & should not be PD
                    
                    ind_U_PD = 2 + (JJ_PD - 1)*(Z1 - 1) + (Z2 - 1); // Y_PD > 84 -- utility indicator for PD
                    
                }else{
                    // if PD occurs, then Z1 and Z2 don't make any change for utility so no need to simulate Z1 and Z2
                    base_PD = fn_compute_H_for_Ut_1(QQ_j, 42.0, SS, lam, s_ind_1, s_ind_2);
                    S_PD_1 = exp(-eta_j*base_PD); // P(conti Y_PD > 42)
                    ind_PD = 0;
                    
                    Z1 = -1;
                    Z2 = -1;
                    prob_q = 1.0 - S_PD_1; // P(Y_PD < 42)
                    
                    if (u <= prob_q) { // P(Y_PD < 42)
                        ind_U_PD = 0; // PD occurred during (0, 42]
                        ind_PD = 1;
                        
                        GetRNGstate();
                        u1 = 0.0 + runif(0.0, 1.0)*(prob_q - 0.0);
                        PutRNGstate();
                        
                        // cumulative hazard for Utility computation
                        for (i_q = 0; i_q < QQ_j; i_q++) {
                            prob_q = 1.0 - exp(-eta_j*Tab_Hazd[s_ind_1 + i_q]);
                            if (u1 <= prob_q) {
                                break;
                            }
                        }//for (i_q = 0; i_q < Q_j; i_q++) {
                        
                        s_star =  fn_min(42.0, SS[s_ind_2 + i_q + 1]);  // Y_PD < 42
                        
                        GetRNGstate();
                        YY[i_j] = SS[s_ind_2 + i_q] + (s_star - SS[s_ind_2 + i_q])*runif(0.0, 1.0);
                        PutRNGstate();
                        
                    }//if (u < prob_q) {// P(Y_PD < 42)
                    
                    prob_q = 1.0 - S_PD_1*(1.0 - Pi_1[0]); // P(Y_PD <= 42)
                    
                    if ((ind_PD==0)&&(u <= prob_q)) {// P(Y_PD = 42)
                        ind_U_PD = 0; // PD occurred during (0, 42]
                        ind_PD = 1;
                        YY[i_j] = 42.0;
                    }//if ((ind_PD==0)&(u <= prob_q)) {// P(Y_PD = 42)
                    
                    prob_q = 1.0 - S_PD_2*(1.0 - Pi_1[0]); // P(Y_PD < 84)
                    if ((ind_PD==0)&&(u <= prob_q)) {// P(Y_PD < 84)
                        ind_U_PD = 1; // PD occurred during (42, 84]
                        ind_PD = 1;
                        
                        GetRNGstate();
                        u1 = (1.0 - S_PD_1) + runif(0.0, 1.0)*(S_PD_1 - S_PD_2);
                        PutRNGstate();
                        
                        // cumulative hazard for Utility computation
                        for (i_q = 0; i_q < QQ_j; i_q++) {
                            prob_q = 1.0 - exp(-eta_j*Tab_Hazd[s_ind_1 + i_q]);
                            if (u1 <= prob_q) {
                                break;
                            }
                        }//for (i_q = 0; i_q < Q_j; i_q++) {
                        
                        s_star =  fn_max(42.0, SS[s_ind_2 + i_q]);  // 42 < Y_PD
                        
                        GetRNGstate();
                        YY[i_j] = s_star + (SS[s_ind_2 + i_q + 1] - SS[s_ind_2 + i_q])*runif(0.0, 1.0);
                        PutRNGstate();
                    }//if ((ind_PD==0)&(u <= prob_q)) {// P(Y_PD = 42)
                    
                    if (ind_PD == 0) { // P(Y_PD <= 84)
                        ind_U_PD = 1; // PD occurred during (42, 84]
                        YY[i_j] = 84.0;
                    }
                } //if (u > prob_q) { // P(Y_PD > 84)
                //## end: PD
                
                // Find the Utility and Safety
                for (i_j = 0; i_j < JJ; i_j++) {
                    if ((YY[i_j] <= Cens[i_j])&(YY[i_j] <= Cens[0])) {
                        Tab_Occ[i_j] = 1;
                        Tab_Safety[i_j*MM + i_d] = Tab_Safety[i_j*MM + i_d] + 1.0;
                    }else{
                        Tab_Occ[i_j] = 0;
                    }//if ((YY[i_j] <= Cens_U[i_j]) && (YY[i_j] < YY[0])) {
                } //for (i_j = 1; i_j < JJ; i_j++) {
                
                
                //> Ut_mat
                if(Tab_Occ[0] == 1)
                {
                    Tab_Exp_Ut[i_d] = Tab_Exp_Ut[i_d] + 0.0; // if death occurrs, utility=0
                }else{
                    //check when tox occurs
                    if(YY[1] <= 42)
                    {
                        ind_U_T = 0;
                    }else{
                        if(YY[1] <= 84)
                        {
                            ind_U_T = 1;
                        }else{
                            ind_U_T = 2;
                        }//if(YY[1] <= 84)
                    }//if(YY[1] <= 42)
                    
                    //tmp =  Ut_tab[ind_U_PD + 11*ind_U_T];
                    Tab_Exp_Ut[i_d] = Tab_Exp_Ut[i_d] + Ut_tab[ind_U_PD + 11*ind_U_T]; // 11 different PD categories for utility computation.
                }//if(Tab_Occ[0] == 1)
                //                 printf("\n Y=%f, %f, %f, ind=%d, %d, %d, Z1=%d, Z2=%d, U=%f", YY[0], YY[1], YY[2], Tab_Occ[0], ind_U_T, ind_U_PD, Z1, Z2, tmp);
                
            }//for (i_d = 0; i_d < MM; i_d++) {
        } //## for(i_sam in 1:n_sam)
        
        // save
        for (i_d =0; i_d < MM; i_d++) {
            Tab_Exp_Ut_1[i_d] = Tab_Exp_Ut_1[i_d] + Tab_Exp_Ut[i_d]/(1.0*n_sam*n_sam_1);
            
            // death: P(Y_D > 12 months) > pi_bar_S  ==> P(Y_D < 12 months) < 1 - pi_bar_S (for death, pi_bar_S has (1-pi_bar_S)
            // PD: P(Y_PD <= 12 weeks) < pi_bar_S
            tmp_D = Tab_Safety[i_d]/(1.0*n_sam_1);  // Death
            tmp_T = Tab_Safety[MM + i_d]/(1.0*n_sam_1);
            tmp_PD = Tab_Safety[2*MM + i_d]/(1.0*n_sam_1);  // PD
            
            if ((tmp_D > pi_bar_S[0])||(tmp_T > pi_bar_S[1])||(tmp_PD > pi_bar_S[2])) {
                Tab_Safety_1[i_d] = Tab_Safety_1[i_d] + 1;  // Not Acceptable
            }//if ((tmp_D > pi_bar_S[0])||(tmp_PD > pi_bar_S[1])) {
        }//for (i_d =0; i_d < MM; i_d++) {
        
        
        delete sq_Omega; sq_Omega = NULL;
        delete gam_vec; gam_vec = NULL;
        delete Pi_1; Pi_1 = NULL;
        delete Pi_2; Pi_2 = NULL;
        delete Tab_Safety; Tab_Safety = NULL;
        delete Tab_Exp_Ut; Tab_Exp_Ut = NULL;
        delete Tab_Occ; Tab_Occ = NULL;
        
        delete YY; YY = NULL;
        delete Tab_dose; Tab_dose = NULL;
        delete Tab_dose_phi; Tab_dose_phi = NULL;
        delete Tab_Hazd; Tab_Hazd = NULL;
    }

    void fn_Discrete_MCMC_U(double *dose, double *YY, int *Z_obs, int *Delta,
                            int *Q_max, int *QQ, double *SS, // s -- hazard cutpoints
                            double *lam, double *sig2, double *lam0, double *sig2_0, // Lambda for all outcomes
                            double *Be, double *Be_bar, double *tau2, // death - Be1 and Be2 // Tox - Be1 // PD - Be1 and Be2
                            // Parameters for Z
                            double *xi, double *xi_bar, double *tau2_xi, // 2-dim vector for t*_1, t*_2
                            double *phi, double *phi_bar, double *tau2_phi, // dose effect para for Z
                            double *Alpha, double *Alpha_bar, double *v2_alpha, // Alpha=(alpha_0, alpha_1, alpha_2, alpha_3)
                            double *sig2_pi, double *u_cutoff,
                            // Gamma - Frailties
                            double *gam, int *nu, double *Omega_0, double *Inv_Omega, // gam_i: (JJ + 1)-dim vector
                            int *JJ, int *JJ_1, int *NNt, int *N_burn, int *N_iter, // JJ=3, JJ_1=4
                            double *std_dose, int *MM, double *Cens, double *pi_bar_S, double *Ut_tab, int *Tab_Safety, double *Tab_Exp_Ut)
    {
        int i_iter, i_j;
        int n_t = *NNt;
        int be_cnt= 7;
        
        double *KK_sum; KK_sum = new double[n_t*(*JJ)];
        double *Len_int; Len_int = new double[(*Q_max)*(*JJ)];
        int *Ind_y; Ind_y = new int[n_t*(*JJ)];
        double *res_y; res_y = new double[n_t*(*JJ)];
        
        int *Accpt_cnt; Accpt_cnt = new int[be_cnt];
        double *v2_MH; v2_MH = new double[be_cnt];
        
        int *Accpt_cnt_Z; Accpt_cnt_Z = new int[5];
        double *v2_MH_Z; v2_MH_Z = new double[5];
        
        int *Accpt_cnt_lam; Accpt_cnt_lam = new int[(*Q_max)*(*JJ)];
        double *v2_MH_lam; v2_MH_lam = new double[(*Q_max)*(*JJ)];
        
        for (i_j=0; i_j < (*JJ); i_j ++) {
            // compute Len_int, Ind_y, res_y
            fn_compute_Len_Ind_res_j(n_t, *Q_max, QQ[i_j], YY, SS, Len_int, Ind_y, res_y, i_j);
            
            // compute KK_sum
            fn_compute_KK_j(n_t, *Q_max, QQ[i_j], lam, Len_int, Ind_y, res_y, KK_sum, i_j);
        }//for (int i_j=0; i_j < (*JJ); i_j ++) {
        
        // initialize MH parameters
        for (i_j=0; i_j < be_cnt; i_j ++) {
            Accpt_cnt[i_j] = 0;
            v2_MH[i_j] = 1.0;
        }//for (i_j=0; i_j < be_cnt; i_j ++) {
        
        for (i_j=0; i_j < 5; i_j ++) {
            Accpt_cnt_Z[i_j] = 0;
            v2_MH_Z[i_j] = 0.5;
        }//for (i_j=0; i_j < be_cnt; i_j ++) {
        
        for (i_j=0; i_j < ((*Q_max)*(*JJ)); i_j ++) {
            Accpt_cnt_lam[i_j] = 0;
            v2_MH_lam[i_j] = 0.5;
        }//for (i_j=0; i_j < be_cnt; i_j ++) {
        
        //printf("\n before Be=%f, Be=%f, Be=%f, Be=%f, Be=%f, Be=%f", Be[0], Be[1], Be[2], Be[3], Be[4], Be[5]);

        // run MCMC for the burn-in period
        fn_Discrete_MCMC_Burn(dose, YY, Z_obs, *Q_max, QQ, Delta, Ind_y, SS, Len_int, res_y,
                              lam, sig2, lam0, sig2_0, KK_sum, Accpt_cnt_lam, v2_MH_lam,
                              Be, Be_bar, tau2, Accpt_cnt, v2_MH,
                              xi, xi_bar, tau2_xi, phi, *phi_bar, *tau2_phi, Alpha, Alpha_bar, v2_alpha, *sig2_pi, u_cutoff, Accpt_cnt_Z, v2_MH_Z,
                              gam, *nu, Omega_0, Inv_Omega, *JJ, *JJ_1, n_t, *N_burn);
        
        //printf("\n after Be=%f, Be=%f, Be=%f, Be=%f, Be=%f, Be=%f", Be[0], Be[1], Be[2], Be[3], Be[4], Be[5]);

        // run MCMC after the burn-in period --- draw samples and compute utility.
        //for (i_iter=0; i_iter < 0; i_iter++) {
        for (i_iter=0; i_iter < (*N_iter); i_iter++) {
            //printf("\n iter=%d", i_iter);
            
            // Update lambda for all j=D, T, PD and update KK_sum_j accordingly
            // Update SS (baseline hazard cutpoints) and update Len_int, Ind_y, & res_y accordingly
            fn_update_lam_SS(n_t, dose, YY, Be, gam, *Q_max, QQ, Delta, lam, sig2, lam0, sig2_0, KK_sum, SS, Len_int, Ind_y, res_y, Accpt_cnt_lam, v2_MH_lam);
            
            // Update Be_D1, Be_D2, Be_T1, Be_PD1 and Be_PD2
            fn_update_Be(n_t, dose, gam, Delta, KK_sum, Be, Be_bar, tau2, Accpt_cnt, v2_MH);
            
            //update random effects -- update gam_{i} as a vector
            fn_update_gam(n_t, *JJ, *JJ_1, u_cutoff, dose, gam, Inv_Omega, Delta, Z_obs, KK_sum, Be, *phi, xi, Alpha, *sig2_pi, 0);
            
            // Update xi, phi (dose effect), Alpha, Psi (latent variables)
            fn_update_Z_para(n_t, *JJ_1, dose, Z_obs, gam, xi, xi_bar, tau2_xi, phi, *phi_bar, *tau2_phi, Alpha, Alpha_bar, v2_alpha, *sig2_pi, u_cutoff, Accpt_cnt_Z, v2_MH_Z);
            
            // Update Inv_Omega  -- Inverse of Covariance Matrix of gam_i -- (J+1)*(J+1)
            fn_update_Inv_Omega(gam, *nu, Omega_0, n_t, (*JJ + 1), Inv_Omega);
            
            /*
            // Update lambda for all j=D, T, PD and update KK_sum_j accordingly
            // Update SS (baseline hazard cutpoints) and update Len_int, Ind_y, & res_y accordingly
            fn_update_lam_SS_1(n_t, dose, YY, Be, gam, *Q_max, QQ, Delta, lam, sig2, lam0, sig2_0, KK_sum, SS, Len_int, Ind_y, res_y);
            
            // Update Be_D1, Be_D2, Be_T1, Be_PD1 and Be_PD2
            fn_update_Be_ALL(n_t, dose, gam, Delta, KK_sum, Be, Be_bar, tau2, Accpt_cnt, v2_MH);
            
            //update random effects -- update gam_{ij} one at a time
            fn_update_gam(n_t, *JJ, *JJ_1, u_cutoff, dose, gam, Inv_Omega, Delta, Z_obs, KK_sum, Be, *phi, xi, Alpha, *sig2_pi, 0);
            
            // Update xi, phi (dose effect), Alpha, Psi (latent variables)
            fn_update_Z_para_ALL(n_t, *JJ_1, dose, Z_obs, gam, xi, xi_bar, tau2_xi, phi, *phi_bar, *tau2_phi, Alpha, Alpha_bar, v2_alpha, *sig2_pi, u_cutoff);
            
            // Update Inv_Omega  -- Inverse of Covariance Matrix of gam_i -- (J+1)*(J+1)
            fn_update_Inv_Omega(gam, *nu, Omega_0, n_t, (*JJ + 1), Inv_Omega);
            */
            
            // compute Uti and safety with the current para ////////************************************************
            fn_compute_Safety_ExpU_one(std_dose, *MM, *JJ, *JJ_1, QQ, *Q_max, u_cutoff, *sig2_pi, SS, Inv_Omega, lam, Be, Alpha, xi, *phi, Cens, pi_bar_S, Ut_tab, Tab_Safety, Tab_Exp_Ut, *N_iter);
            
            // adjust MH parameters for Be
            if ((i_iter % 50) == 0) {
                fn_adjust_v2_MH(Accpt_cnt, v2_MH, ((*N_burn + i_iter)/50));
                fn_adjust_v2_MH_Z(Accpt_cnt_Z, v2_MH_Z, ((*N_burn + i_iter)/50));
                fn_adjust_v2_MH_lam(Accpt_cnt_lam, v2_MH_lam, *Q_max, QQ, *JJ, ((*N_burn + i_iter)/50));
            }
        }
        
        //printf("\n after II Be=%f, Be=%f, Be=%f, Be=%f, Be=%f, Be=%f", Be[0], Be[1], Be[2], Be[3], Be[4], Be[5]);
        
        delete KK_sum; KK_sum = NULL;
        delete Len_int; Len_int = NULL;
        delete Ind_y; Ind_y = NULL;
        delete res_y; res_y = NULL;
        delete Accpt_cnt; Accpt_cnt = NULL;
        delete v2_MH; v2_MH = NULL;
        delete Accpt_cnt_Z; Accpt_cnt_Z = NULL;
        delete v2_MH_Z; v2_MH_Z = NULL;
        delete Accpt_cnt_lam; Accpt_cnt_lam = NULL;
        delete v2_MH_lam; v2_MH_lam = NULL;
    }
    
    

    //compute safety prob & expected utility given \theta
    // Tab_Safety: JJ*MM matrix
    // Tab_Exp_Ut: MM matrix
    void fn_compute_prob(double *Dose, int MM, int JJ, int JJ_PD, int *QQ, int max_QQ, double *u_cutoff, double sig2_pi, double *SS,
                         double *Inv_Omega, double *lam, double *Be, double *Alpha, double *xi, double phi,
                         double *Cens, int n_sam, double *Tmp_prob)
    {
        
        int ii_sam, i_j, ii_j, s_ind_1, s_ind_2, i_d, ii, i_q, QQ_j;
        double tmp_PD, tmp_D, tmp_T, tmp_z, u, u1, AA, Pi_20, eta_j, prob_q;
        double S_PD_1, S_PD_2, base_PD, s_star;
        int ind_PD;
        
        int n_sam_1 = 100;   //## marginalize over random effects
        
        double *sq_Omega; sq_Omega = new double[(JJ + 1)*(JJ + 1)];
        double *gam_vec; gam_vec = new double[JJ + 1];
        
        double *Tab_Safety; Tab_Safety = new double[JJ*MM];  // (JJ*MM)-dim matrix
        
        // dose effects (JJ * MM) and baseline cumulative hazards
        double *Tab_dose; Tab_dose = new double[(JJ + 1)*MM];  // JJ*MM matrix
        double *Tab_dose_phi; Tab_dose_phi = new double[MM];   // JJ*MM matrix
        
        double *YY; YY = new double[JJ];  // JJ-dim vector
        double *Pi_1; Pi_1 = new double[JJ_PD];  // JJ_PD-dim vector
        double *Tab_Hazd; Tab_Hazd = new double[max_QQ*JJ];     // JJ-dim vector
        
        // how many times safe among n_sam_1
        for (ii=0; ii < (JJ*MM); ii++) {
            Tab_Safety[ii] = 0.0;
        }
        
        // compute dose effects (each dose) for D, T and PD
        for (i_d = 0; i_d < MM; i_d++) { //JJ*MM matrix
            Tab_dose[JJ*i_d + 0] =  Be[1]/(1.0 + exp(Be[0]*(10.0*Dose[i_d] - Be[2])));  // Death
            Tab_dose[JJ*i_d + 1] =  Be[4]/(1.0 + exp(Be[3]*(10.0*Dose[i_d] - Be[5])));  // Tox
            Tab_dose[JJ*i_d + 2] =  Be[6]*Dose[i_d];                  // conti-PD
            Tab_dose_phi[i_d] =  phi*Dose[i_d];                       // discrete-PD
            
            //printf("\n i_d=%d, eta_d=%f, eta_t=%f, eta_PD=%f, eta_PD=%f", i_d, Tab_dose[JJ*i_d + 0], Tab_dose[JJ*i_d + 1], Tab_dose[JJ*i_d + 2], Tab_dose_phi[i_d]);
        }
        
        // compute baseline hazard for D, T and PD
        // for utility computation - for all D, T and PD
        for (i_j = 0; i_j < JJ; i_j++) {
            // \sum exp(lam_{jq})*(s_jq - s_jq-1) only for follow-up
            fn_compute_H_for_Ut(QQ[i_j], SS, lam, max_QQ*i_j, (max_QQ + 1)*i_j, Tab_Hazd);
        }//for (i_j = 0; i_j < JJ; i_j++) {
        
        //gam_vec[0] = 0.0;
        //gam_vec[1] = 0.0;
        //gam_vec[2] = 0.0;
        //gam_vec[3] = 0.0;

        //printf("\n\n");
        
        // Find the square root inverse of p*p matrix Inv_Omega and save it in sq_Omega
        fn_sq_inverse_mat(JJ+1, Inv_Omega, sq_Omega);
        
        for (ii_sam = 0; ii_sam < n_sam_1; ii_sam ++) { // marginalize over gamma
            
            //Simulate a gamma vector -- Frailty: generate samples from N(0, Sig=) where sq_Sigma = \sqrt(Sigma)
            mvn_rv(JJ+1, sq_Omega, gam_vec);
            
            for (i_d = 0; i_d < MM; i_d++) {
                
                //## begin: death & tox
                // i_j = 0 (D), 1 (Tox)
                for (i_j = 0; i_j < 2; i_j ++) {
                    s_ind_1 =  max_QQ*i_j;
                    s_ind_2 =  (max_QQ + 1)*i_j;
                    QQ_j = QQ[i_j];
                    eta_j = exp(gam_vec[i_j] + Tab_dose[JJ*i_d + i_j]);
                    
                    GetRNGstate();
                    u = runif(0.0, 1.0);
                    PutRNGstate();
                    
                    // cumulative hazard for Utility computation
                    for (i_q = 0; i_q < QQ_j; i_q++) {
                        prob_q = 1.0 - exp(-eta_j*Tab_Hazd[s_ind_1 + i_q]);
                        
                        if (u <= prob_q) {
                            break;
                        }
                    }//for (i_q = 0; i_q < Q_j; i_q++) {
                    
                    prob_q = 1.0 - exp(-eta_j*Tab_Hazd[s_ind_1 + QQ_j - 1]); // P(Y_j <= C_j) where C_j for safety
                    
                    //printf("\n i_d=%d, j=%d, prob=%f", i_d, i_j, prob_q);
                    
                    if(u <= prob_q)
                    {
                        GetRNGstate();
                        YY[i_j] = SS[s_ind_2 + i_q] + (SS[s_ind_2 + i_q + 1] - SS[s_ind_2 + i_q])*runif(0.0, 1.0);
                        PutRNGstate();
                    }else{
                        YY[i_j] = SS[s_ind_2 + QQ_j] + 100.0;
                    }//if(u <= prob_q)
                }//for (i_j = 0; i_j < 2; i_j ++) {
                //## end: Death & Tox
                
                //## begin: PD -- Expected Uti
                i_j = 2; // PD
                s_ind_1 =  max_QQ*i_j;
                s_ind_2 =  (max_QQ + 1)*i_j;
                QQ_j = QQ[i_j];
                eta_j = exp(gam_vec[i_j] + Tab_dose[JJ*i_d + i_j]);
                
                // P(Z1) -- cumulative
                tmp_z = xi[0] + gam_vec[i_j + 1] + Tab_dose_phi[i_d]; // mean for t*_1
                for (ii_j = 0; ii_j < (JJ_PD-1); ii_j++) {
                    //pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE)
                    Pi_1[ii_j] = pnorm(u_cutoff[ii_j], tmp_z, sqrt(sig2_pi), 1, 0);
                }
                Pi_1[JJ_PD - 1] = 1.0;
                
                // P(Z2=0 |Z1)
                AA = 0.0;
                for (ii_j = 1; ii_j < JJ_PD; ii_j++) {
                    tmp_z = xi[1] + gam_vec[i_j + 1] + Tab_dose_phi[i_d] + Alpha[ii_j]; // mean for t*_2
                    Pi_20 = pnorm(u_cutoff[0], tmp_z, sqrt(sig2_pi), 1, 0); // Pr(Z2=0 | Z1)
                    
                    AA = AA + (Pi_1[ii_j] - Pi_1[ii_j - 1])*(1.0 - Pi_20); // \sum p(z1)(1-p(z2=0 | z1), z1= 1, 2, 3
                }//for (ii_j = 1; ii_j < (JJ_PD-1); ii_j++) {
                
                // -- PD
                GetRNGstate();
                u = runif(0.0, 1.0);
                PutRNGstate();
                
                S_PD_2 = exp(-eta_j*Tab_Hazd[s_ind_1 + QQ_j - 1]);  // since C_PD = S_PD
                prob_q = 1.0 - S_PD_2*AA; // P(Y_PD <= 84)
                ind_PD = 0;
                
                //printf("\n i_d=%d, j=%d, prob=%f", i_d, i_j, prob_q);

                
                if (u > prob_q) { // P(Y_PD > 84)
                    YY[i_j] = SS[s_ind_2 + QQ_j] + 100.0;  // dummy: anything > 84
                }else{
                    base_PD = fn_compute_H_for_Ut_1(QQ_j, 42.0, SS, lam, s_ind_1, s_ind_2);
                    S_PD_1 = exp(-eta_j*base_PD);
                    
                    prob_q = 1.0 - S_PD_1; // P(Y_PD < 42)
                    
                    if (u <= prob_q) { // P(Y_PD < 42)
                        ind_PD = 1;
                        
                        GetRNGstate();
                        u1 = 0.0 + runif(0.0, 1.0)*(prob_q - 0.0);
                        PutRNGstate();
                        
                        // cumulative hazard for Utility computation
                        for (i_q = 0; i_q < QQ_j; i_q++) {
                            prob_q = 1.0 - exp(-eta_j*Tab_Hazd[s_ind_1 + i_q]);
                            if (u1 <= prob_q) {
                                break;
                            }
                        }//for (i_q = 0; i_q < Q_j; i_q++) {
                        
                        s_star =  fn_min(42.0, SS[s_ind_2 + i_q + 1]);  // Y_PD < 42
                        
                        GetRNGstate();
                        YY[i_j] = SS[s_ind_2 + i_q] + (s_star - SS[s_ind_2 + i_q])*runif(0.0, 1.0);
                        PutRNGstate();
                    }//if (u < prob_q) {// P(Y_PD < 42)
                    
                    prob_q = 1.0 - S_PD_1*(1.0 - Pi_1[0]); // P(Y_PD <= 42)
                    
                    if ((ind_PD==0)&&(u <= prob_q)) {// P(Y_PD = 42)
                        ind_PD = 1;
                        YY[i_j] = 42.0;
                    }//if ((ind_PD==0)&(u <= prob_q)) {// P(Y_PD = 42)
                    
                    prob_q = 1.0 - S_PD_2*(1.0 - Pi_1[0]); // P(Y_PD < 84)
                    
                    if ((ind_PD==0)&&(u <= prob_q)) {// P(Y_PD < 84)
                        ind_PD = 1;
                        
                        GetRNGstate();
                        u1 = (1.0 - S_PD_1) + runif(0.0, 1.0)*(S_PD_1 - S_PD_2);
                        PutRNGstate();
                        
                        // cumulative hazard for Utility computation
                        for (i_q = 0; i_q < QQ_j; i_q++) {
                            prob_q = 1.0 - exp(-eta_j*Tab_Hazd[s_ind_1 + i_q]);
                            if (u1 <= prob_q) {
                                break;
                            }
                        }//for (i_q = 0; i_q < Q_j; i_q++) {
                        
                        s_star =  fn_max(42.0, SS[s_ind_2 + i_q]);  // 42 < Y_PD
                        
                        GetRNGstate();
                        YY[i_j] = s_star + (SS[s_ind_2 + i_q + 1] - SS[s_ind_2 + i_q])*runif(0.0, 1.0);
                        PutRNGstate();
                    }//if ((ind_PD==0)&(u <= prob_q)) {// P(Y_PD = 42)
                    
                    if (ind_PD == 0) { // P(Y_PD <= 84)
                        YY[i_j] = 84.0;
                    }
                } //if (u > prob_q) { // P(Y_PD > 84)
                //## end: PD
                
                //printf("\n\n i_d=%d, D=%f, T=%f, PD=%f", i_d, YY[0], YY[1], YY[2]);
                
                // Find the Utility and Safety
                for (i_j = 0; i_j < JJ; i_j++) {
                    if ((YY[i_j] <= Cens[i_j])&(YY[i_j] <= Cens[0])) { // occurred during follow-up
                        Tab_Safety[i_j*MM + i_d] = Tab_Safety[i_j*MM + i_d] + 1.0;
                    }
                } //for (i_j = 1; i_j < JJ; i_j++) {
            }//for (i_d = 0; i_d < MM; i_d++) {
        } //## for(i_sam in 1:n_sam)
        
        // save
        for (i_d =0; i_d < MM; i_d++) {
            // death: P(Y_D > 12 months) > pi_bar_S  ==> P(Y_D < 12 months) < 1 - pi_bar_S (for death, pi_bar_S has (1-pi_bar_S)
            // Tox: P(Y_T <= 12 weeks) < pi_bar_S
            // PD: P(Y_PD <= 12 weeks) < pi_bar_S
            tmp_D = Tab_Safety[i_d]/(1.0*n_sam_1);
            tmp_T = Tab_Safety[MM + i_d]/(1.0*n_sam_1);
            tmp_PD = Tab_Safety[2*MM + i_d]/(1.0*n_sam_1);
            
            Tmp_prob[i_d] = tmp_D;
            Tmp_prob[MM + i_d] = tmp_T;
            Tmp_prob[2*MM + i_d] = tmp_PD;
            
        }//for (i_d =0; i_d < MM; i_d++) {
        
        delete sq_Omega; sq_Omega = NULL;
        delete gam_vec; gam_vec = NULL;
        delete Pi_1; Pi_1 = NULL;
        delete Tab_Safety; Tab_Safety = NULL;
        
        delete YY; YY = NULL;
        delete Tab_dose; Tab_dose = NULL;
        delete Tab_dose_phi; Tab_dose_phi = NULL;
        delete Tab_Hazd; Tab_Hazd = NULL;
        
    }
    
    void fn_Discrete_MCMC_U_1(double *dose, double *YY, int *Z_obs, int *Delta,
                              int *Q_max, int *QQ, double *SS, // s -- hazard cutpoints
                              double *lam, double *sig2, double *lam0, double *sig2_0, // Lambda for all outcomes
                              double *Be, double *Be_bar, double *tau2, // death - Be1 and Be2 // Tox - Be1 // PD - Be1 and Be2
                              // Parameters for Z
                              double *xi, double *xi_bar, double *tau2_xi, // 2-dim vector for t*_1, t*_2
                              double *phi, double *phi_bar, double *tau2_phi, // dose effect para for Z
                              double *Alpha, double *Alpha_bar, double *v2_alpha, // Alpha=(alpha_0, alpha_1, alpha_2, alpha_3)
                              double *sig2_pi, double *u_cutoff,
                              // Gamma - Frailties
                              double *gam, int *nu, double *Omega_0, double *Inv_Omega, // gam_i: (JJ + 1)-dim vector
                              int *JJ, int *JJ_1, int *NNt, int *N_burn, int *N_iter, // JJ=3, JJ_1=4
                              double *std_dose, int *MM, double *Cens, double *pi_bar_S, double *Ut_tab, int *Tab_Safety, double *Tab_Exp_Ut,
                              double *Prob_sam, double *Be_sam, double *Lam_sam)
    {
        int i_iter, i_j;
        int n_t = *NNt;
        int be_cnt= 7;
        
        double *KK_sum; KK_sum = new double[n_t*(*JJ)];
        double *Len_int; Len_int = new double[(*Q_max)*(*JJ)];
        int *Ind_y; Ind_y = new int[n_t*(*JJ)];
        double *res_y; res_y = new double[n_t*(*JJ)];
        
        int *Accpt_cnt; Accpt_cnt = new int[be_cnt];
        double *v2_MH; v2_MH = new double[be_cnt];
        
        int *Accpt_cnt_Z; Accpt_cnt_Z = new int[5];
        double *v2_MH_Z; v2_MH_Z = new double[5];
        
        int *Accpt_cnt_lam; Accpt_cnt_lam = new int[(*Q_max)*(*JJ)];
        double *v2_MH_lam; v2_MH_lam = new double[(*Q_max)*(*JJ)];
        
        for (i_j=0; i_j < (*JJ); i_j ++) {
            // compute Len_int, Ind_y, res_y
            fn_compute_Len_Ind_res_j(n_t, *Q_max, QQ[i_j], YY, SS, Len_int, Ind_y, res_y, i_j);
            
            // compute KK_sum
            fn_compute_KK_j(n_t, *Q_max, QQ[i_j], lam, Len_int, Ind_y, res_y, KK_sum, i_j);
        }//for (int i_j=0; i_j < (*JJ); i_j ++) {
        
        // initialize MH parameters
        for (i_j=0; i_j < be_cnt; i_j ++) {
            Accpt_cnt[i_j] = 0;
            v2_MH[i_j] = 1.0;
        }//for (i_j=0; i_j < be_cnt; i_j ++) {
        
        for (i_j=0; i_j < 5; i_j ++) {
            Accpt_cnt_Z[i_j] = 0;
            v2_MH_Z[i_j] = 0.5;
        }//for (i_j=0; i_j < be_cnt; i_j ++) {
        
        for (i_j=0; i_j < ((*Q_max)*(*JJ)); i_j ++) {
            Accpt_cnt_lam[i_j] = 0;
            v2_MH_lam[i_j] = 0.5;
        }//for (i_j=0; i_j < be_cnt; i_j ++) {
        
        
        int ind_s, ii, MJ=(*JJ)*(*MM);
        
        double *Tmp_prob; Tmp_prob = new double[MJ];
        
        for (i_j=0; i_j < (*JJ); i_j ++) {
            // compute Len_int, Ind_y, res_y
            fn_compute_Len_Ind_res_j(n_t, *Q_max, QQ[i_j], YY, SS, Len_int, Ind_y, res_y, i_j);
            
            // compute KK_sum
            fn_compute_KK_j(n_t, *Q_max, QQ[i_j], lam, Len_int, Ind_y, res_y, KK_sum, i_j);
        }//for (int i_j=0; i_j < (*JJ); i_j ++) {
        
        // initialize MH parameters
        for (i_j=0; i_j < be_cnt; i_j ++) {
            Accpt_cnt[i_j] = 0;
            v2_MH[i_j] = 1.0;
        }//for (i_j=0; i_j < be_cnt; i_j ++) {
        
        for (i_j=0; i_j < 5; i_j ++) {
            Accpt_cnt_Z[i_j] = 0;
            v2_MH_Z[i_j] = 0.5;
        }//for (i_j=0; i_j < be_cnt; i_j ++) {
        
        for (i_j=0; i_j < ((*Q_max)*(*JJ)); i_j ++) {
            Accpt_cnt_lam[i_j] = 0;
            v2_MH_lam[i_j] = 0.5;
        }//for (i_j=0; i_j < be_cnt; i_j ++) {
        
        // run MCMC for the burn-in period
        fn_Discrete_MCMC_Burn(dose, YY, Z_obs, *Q_max, QQ, Delta, Ind_y, SS, Len_int, res_y,
                              lam, sig2, lam0, sig2_0, KK_sum, Accpt_cnt_lam, v2_MH_lam,
                              Be, Be_bar, tau2, Accpt_cnt, v2_MH,
                              xi, xi_bar, tau2_xi, phi, *phi_bar, *tau2_phi, Alpha, Alpha_bar, v2_alpha, *sig2_pi, u_cutoff, Accpt_cnt_Z, v2_MH_Z,
                              gam, *nu, Omega_0, Inv_Omega, *JJ, *JJ_1, n_t, *N_burn);
        
        // run MCMC after the burn-in period --- draw samples and compute utility.
        for (i_iter=0; i_iter < (*N_iter); i_iter++) {
        //for (i_iter=0; i_iter < 1; i_iter++) {
            //printf("\n iter=%d", i_iter);
            
            // Update lambda for all j=D, T, PD and update KK_sum_j accordingly
            // Update SS (baseline hazard cutpoints) and update Len_int, Ind_y, & res_y accordingly
            fn_update_lam_SS(n_t, dose, YY, Be, gam, *Q_max, QQ, Delta, lam, sig2, lam0, sig2_0, KK_sum, SS, Len_int, Ind_y, res_y, Accpt_cnt_lam, v2_MH_lam);
            
            // Update Be_D1, Be_D2, Be_T1, Be_PD1 and Be_PD2
            fn_update_Be(n_t, dose, gam, Delta, KK_sum, Be, Be_bar, tau2, Accpt_cnt, v2_MH);
            
            //update random effects -- update gam_{i} as a vector
            fn_update_gam(n_t, *JJ, *JJ_1, u_cutoff, dose, gam, Inv_Omega, Delta, Z_obs, KK_sum, Be, *phi, xi, Alpha, *sig2_pi, 0);
            
            // Update xi, phi (dose effect), Alpha, Psi (latent variables)
            fn_update_Z_para(n_t, *JJ_1, dose, Z_obs, gam, xi, xi_bar, tau2_xi, phi, *phi_bar, *tau2_phi, Alpha, Alpha_bar, v2_alpha, *sig2_pi, u_cutoff, Accpt_cnt_Z, v2_MH_Z);
            
            // Update Inv_Omega  -- Inverse of Covariance Matrix of gam_i -- (J+1)*(J+1)
            fn_update_Inv_Omega(gam, *nu, Omega_0, n_t, (*JJ + 1), Inv_Omega);
            
            // Update lambda for all j=D, T, PD and update KK_sum_j accordingly
            // Update SS (baseline hazard cutpoints) and update Len_int, Ind_y, & res_y accordingly
            //fn_update_lam_SS_1(n_t, dose, YY, Be, gam, *Q_max, QQ, Delta, lam, sig2, lam0, sig2_0, KK_sum, SS, Len_int, Ind_y, res_y);
            
            // Update Be_D1, Be_D2, Be_T1, Be_PD1 and Be_PD2
            //fn_update_Be_ALL(n_t, dose, gam, Delta, KK_sum, Be, Be_bar, tau2, Accpt_cnt, v2_MH);
            
            //update random effects -- update gam_{ij} one at a time
            //fn_update_gam(n_t, *JJ, *JJ_1, u_cutoff, dose, gam, Inv_Omega, Delta, Z_obs, KK_sum, Be, *phi, xi, Alpha, *sig2_pi, 0);
            
            // Update xi, phi (dose effect), Alpha, Psi (latent variables)
            //fn_update_Z_para_ALL(n_t, *JJ_1, dose, Z_obs, gam, xi, xi_bar, tau2_xi, phi, *phi_bar, *tau2_phi, Alpha, Alpha_bar, v2_alpha, *sig2_pi, u_cutoff);
            
            // Update Inv_Omega  -- Inverse of Covariance Matrix of gam_i -- (J+1)*(J+1)
            //fn_update_Inv_Omega(gam, *nu, Omega_0, n_t, (*JJ + 1), Inv_Omega);
            
            // compute Uti and safety with the current para ////////************************************************
            fn_compute_Safety_ExpU_one(std_dose, *MM, *JJ, *JJ_1, QQ, *Q_max, u_cutoff, *sig2_pi, SS, Inv_Omega, lam, Be, Alpha, xi, *phi, Cens, pi_bar_S, Ut_tab, Tab_Safety, Tab_Exp_Ut, *N_iter);
            
            // adjust MH parameters for Be
            if ((i_iter % 50) == 0) {
                fn_adjust_v2_MH(Accpt_cnt, v2_MH, ((*N_burn + i_iter)/50));
                fn_adjust_v2_MH_Z(Accpt_cnt_Z, v2_MH_Z, ((*N_burn + i_iter)/50));
                fn_adjust_v2_MH_lam(Accpt_cnt_lam, v2_MH_lam, *Q_max, QQ, *JJ, ((*N_burn + i_iter)/50));
            }
            
            // compute Uti and safety with the current para ////////************************************************
            fn_compute_prob(std_dose, *MM, *JJ, *JJ_1, QQ, *Q_max, u_cutoff, *sig2_pi, SS, Inv_Omega, lam, Be, Alpha, xi, *phi, Cens, *N_iter, Tmp_prob);
            
            //save current para ////////
            ind_s = MJ*i_iter;
            for (ii=0; ii < MJ; ii++) {
                Prob_sam[ind_s + ii] = Tmp_prob[ii];
            }
            
            //save current para ////////
            ind_s = 6*i_iter;
            for (ii=0; ii < 6; ii++) {
                Be_sam[ind_s + ii] = Be[ii];
                Lam_sam[ind_s + ii] = lam[ii];
            }
        }
        
        delete Tmp_prob; Tmp_prob = NULL;
        
        delete KK_sum; KK_sum = NULL;
        delete Len_int; Len_int = NULL;
        delete Ind_y; Ind_y = NULL;
        delete res_y; res_y = NULL;
        delete Accpt_cnt; Accpt_cnt = NULL;
        delete v2_MH; v2_MH = NULL;
        delete Accpt_cnt_Z; Accpt_cnt_Z = NULL;
        delete v2_MH_Z; v2_MH_Z = NULL;
        delete Accpt_cnt_lam; Accpt_cnt_lam = NULL;
        delete v2_MH_lam; v2_MH_lam = NULL;
    }
    

}

